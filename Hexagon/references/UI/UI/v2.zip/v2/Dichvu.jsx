// import React, { useState, useEffect } from 'react'
// import ServiceCard from '../../components/card/ServiceCard'
// import { useLanguageStandalone } from '../../../context/LanguageContext'

// const API_URL = (typeof import.meta !== 'undefined' && import.meta.env?.PUBLIC_API_URL) || 'http://localhost:9394/api';

// const getImageUrl = (imagePath) => {
//     if (!imagePath) return null;
//     let src = imagePath;
//     if (typeof src === 'object' && src !== null) {
//         src = src.path || src.filename || null;
//     } else if (typeof src === 'string' && src.trimStart().startsWith('{')) {
//         try {
//             const parsed = JSON.parse(src);
//             src = parsed.path || parsed.filename || src;
//         } catch { }
//     }
//     if (!src) return null;
//     if (src.startsWith('http')) return src;
//     const baseUrl = API_URL.replace('/api', '');
//     if (src.startsWith('/')) return `${baseUrl}${src}`;
//     return `${baseUrl}/uploads/${src}`;
// };

// const buildServiceHref = (service, lang = 'vi') => {
//     const rawLink = service.link || '';
//     const slug = rawLink.replace(/^\//, '');
//     if (!slug) {
//         console.warn('[Dichvu] Service missing link:', service.id, service.title);
//         return '/';
//     }
//     return `/${lang}/${slug}`;
// };

// const TEXT = {
//     vi: {
//         heading: 'Lĩnh vực hoạt động',
//         subheading: 'Tại Hexagon, chúng tôi tập trung phát triển hệ sinh thái công nghệ toàn diện, bao gồm:',
//         empty: 'Chưa có dịch vụ nào được xuất bản.',
//     },
//     en: {
//         heading: 'Our Services',
//         subheading: 'At Hexagon, we focus on building a comprehensive technology ecosystem, including:',
//         empty: 'No published services yet.',
//     },
// };

// function Dichvu() {
//     const { lang } = useLanguageStandalone();
//     const [services, setServices] = useState([]);
//     const [loading, setLoading] = useState(true);

//     useEffect(() => {
//         const fetchServices = async () => {
//             setLoading(true);
//             try {
//                 const res = await fetch(`${API_URL}/services?lang=${lang}`);
//                 const result = await res.json();
//                 if (result.success && Array.isArray(result.data?.services)) {
//                     setServices(result.data.services);
//                 } else {
//                     setServices([]);
//                 }
//             } catch (err) {
//                 console.error('Failed to load services:', err);
//                 setServices([]);
//             } finally {
//                 setLoading(false);
//             }
//         };
//         fetchServices();
//     }, [lang]);

//     const t = TEXT[lang] || TEXT.vi;

//     return (
//         <section id="dich-vu" className="py-8 bg-slate-50">
//             <div className="container max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 w-full">
//                 <div className="text-center mb-4">
//                     <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-black leading-tight">{t.heading}</h2>
//                     <p className="text-gray-700 mt-2 text-sm sm:text-base leading-relaxed px-4">
//                         {t.subheading}
//                     </p>
//                 </div>

//                 {loading ? (
//                     <div className="flex justify-center items-center py-16">
//                         <div className="w-10 h-10 border-4 border-yellow-400 border-t-transparent rounded-full animate-spin"></div>
//                     </div>
//                 ) : services.length === 0 ? (
//                     <p className="text-center text-gray-500">{t.empty}</p>
//                 ) : (
//                     <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-6">
//                         {services.map((service) => (
//                             <ServiceCard
//                                 key={service.id}
//                                 href={buildServiceHref(service, lang)}
//                                 title={service.title}
//                                 description={service.description}
//                                 image={getImageUrl(service.image)}
//                                 heightClass="h-[400px]"
//                             />
//                         ))}
//                     </div>
//                 )}
//             </div>
//         </section>
//     )
// }

// export default Dichvu
import React, { useState, useEffect } from 'react'
import ServiceCard from '../../components/card/ServiceCard'
import { useLanguageStandalone } from '../../../context/LanguageContext'

const API_URL = (typeof import.meta !== 'undefined' && import.meta.env?.PUBLIC_API_URL) || 'http://localhost:9394/api';

// Hàm xử lý đường dẫn ảnh từ API (lấy từ service.image)
const getImageUrl = (imagePath) => {
    if (!imagePath) return null;
    let src = imagePath;
    if (typeof src === 'object' && src !== null) {
        src = src.path || src.filename || null;
    } else if (typeof src === 'string' && src.trimStart().startsWith('{')) {
        try {
            const parsed = JSON.parse(src);
            src = parsed.path || parsed.filename || src;
        } catch { }
    }
    if (!src) return null;
    if (src.startsWith('http')) return src;
    const baseUrl = API_URL.replace('/api', '');
    if (src.startsWith('/')) return `${baseUrl}${src}`;
    return `${baseUrl}/uploads/${src}`;
};

const buildServiceHref = (service, lang = 'vi') => {
    const rawLink = service.link || '';
    const slug = rawLink.replace(/^\//, '');
    if (!slug) {
        console.warn('[Dichvu] Service missing link:', service.id, service.title);
        return '/';
    }
    return `/${lang}/${slug}`;
};

const TEXT = {
    vi: {
        heading: 'Lĩnh vực hoạt động',
        subheading: 'Tại Hexagon, chúng tôi tập trung phát triển hệ sinh thái công nghệ toàn diện, bao gồm:',
        empty: 'Chưa có dịch vụ nào được xuất bản.',
    },
    en: {
        heading: 'Our Services',
        subheading: 'At Hexagon, we focus on building a comprehensive technology ecosystem, including:',
        empty: 'No published services yet.',
    },
};

// Ảnh hover dùng chung cho tất cả các card (crossfade khi hover)
const HOVER_IMAGE = 'https://beta-api.hexagon.xyz/uploads/hovermyc-1-1782467371060-195987948.png';

function Dichvu() {
    const { lang } = useLanguageStandalone();
    const [services, setServices] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchServices = async () => {
            setLoading(true);
            try {
                const res = await fetch(`${API_URL}/services?lang=${lang}`);
                const result = await res.json();
                if (result.success && Array.isArray(result.data?.services)) {
                    setServices(result.data.services);
                } else {
                    setServices([]);
                }
            } catch (err) {
                console.error('Failed to load services:', err);
                setServices([]);
            } finally {
                setLoading(false);
            }
        };
        fetchServices();
    }, [lang]);

    const t = TEXT[lang] || TEXT.vi;

    return (
        <section id="dich-vu" className="py-8 bg-slate-50">
            <div className="container max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 w-full">
                <div className="text-center mb-4">
                    <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-black leading-tight">{t.heading}</h2>
                    <p className="text-gray-700 mt-2 text-sm sm:text-base leading-relaxed px-4">
                        {t.subheading}
                    </p>
                </div>

                {loading ? (
                    <div className="flex justify-center items-center py-16">
                        <div className="w-10 h-10 border-4 border-yellow-400 border-t-transparent rounded-full animate-spin"></div>
                    </div>
                ) : services.length === 0 ? (
                    <p className="text-center text-gray-500">{t.empty}</p>
                ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-6">
                        {services.map((service) => (
                            <ServiceCard
                                key={service.id}
                                href={buildServiceHref(service, lang)}
                                title={service.title}
                                description={
                                    <span className="text-black">
                                        {service.description}
                                    </span>
                                }
                                image={getImageUrl(service.image)}
                                hoverImage={HOVER_IMAGE}
                                heightClass="h-[400px]"
                            />
                        ))}
                    </div>
                )}
            </div>
        </section>
    )
}

export default Dichvu
