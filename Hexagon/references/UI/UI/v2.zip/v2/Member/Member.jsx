import React from "react";
import "./Member.css";

/**
 * Component Member — Hiển thị thanh trượt logo hội viên
 * (CLB Doanh nhân Đồng Tháp tại TP. Hồ Chí Minh)
 */
export default function Member() {
    // Đường dẫn ảnh logo dùng chung cho 2 nhóm (nhân bản để tạo vòng lặp vô tận)
    const logoImages = [
        { src: "https://webdemo.hexagon.xyz/medias/Logo Khoi E.png", alt: "Logo Khối E" },
        { src: "https://webdemo.hexagon.xyz/medias/Logo Khoi C.png", alt: "Logo Khối C" },
        { src: "https://webdemo.hexagon.xyz/medias/Logo Khoi D.png", alt: "Logo Khối D" },
        { src: "https://webdemo.hexagon.xyz/medias/Happy Food.png", alt: "Logo Happy Food" },
        { src: "https://webdemo.hexagon.xyz/medias/B.png", alt: "Binh Minh" },
        { src: "https://webdemo.hexagon.xyz/medias/Logo Khoi F.png", alt: "Logo Khối F" },
    ];

    // Logo SVG tùy chỉnh (ECOBOOK & COMOON)
    const EcoLogo = () => (
        <div className="custom-logo eco-logo">
            <svg viewBox="0 0 80 40" width="80" height="32" style={{ display: "block", margin: "0 auto 4px" }}>
                <path
                    d="M 15 25 C 25 15, 38 15, 40 20 C 42 15, 55 15, 65 25 C 55 18, 42 18, 40 23 C 38 18, 25 18, 15 25 Z"
                    fill="#22c55e"
                />
                <path
                    d="M 18 18 C 26 10, 38 10, 40 15 C 42 10, 54 10, 62 18 C 54 12, 42 12, 40 17 C 38 12, 26 12, 18 18 Z"
                    fill="#eab308"
                />
                <path
                    d="M 22 11 C 28 5, 38 5, 40 10 C 42 5, 52 5, 58 11 C 52 7, 42 7, 40 12 C 38 7, 28 7, 22 11 Z"
                    fill="#22c55e"
                />
            </svg>
            <div className="logo-text eco-text">ECOBOOK</div>
        </div>
    );

    const ComoonLogo = () => (
        <div className="custom-logo comoon-logo">
            <svg viewBox="0 0 80 40" width="80" height="32" style={{ display: "block", margin: "0 auto 4px" }}>
                <path
                    d="M 20 12 C 30 5, 50 5, 60 12 C 55 18, 45 18, 40 18 C 35 18, 25 18, 20 12 Z"
                    fill="#15803d"
                />
                <path
                    d="M 22 17 C 30 11, 50 11, 58 17 C 53 23, 47 23, 40 23 C 33 23, 27 23, 22 17 Z"
                    fill="#eab308"
                />
                <path
                    d="M 25 22 C 32 17, 48 17, 55 22 C 50 30, 45 32, 40 32 C 35 32, 30 30, 25 22 Z"
                    fill="#15803d"
                />
            </svg>
            <div className="logo-text comoon-text">COMOON</div>
        </div>
    );

    // Render 1 nhóm logo (gồm ảnh + 2 SVG tùy chỉnh theo đúng thứ tự gốc)
    const renderGroup = (keyPrefix) => (
        <>
            <div key={`${keyPrefix}-e`} className="logo-card">
                <img src={logoImages[0].src} alt={logoImages[0].alt} />
            </div>
            <div key={`${keyPrefix}-c`} className="logo-card">
                <img src={logoImages[1].src} alt={logoImages[1].alt} />
            </div>
            <div key={`${keyPrefix}-d`} className="logo-card">
                <img src={logoImages[2].src} alt={logoImages[2].alt} />
            </div>
            <div key={`${keyPrefix}-happy`} className="logo-card">
                <img src={logoImages[3].src} alt={logoImages[3].alt} />
            </div>
            <div key={`${keyPrefix}-eco`} className="logo-card">
                <EcoLogo />
            </div>
            <div key={`${keyPrefix}-comoon`} className="logo-card">
                <ComoonLogo />
            </div>
            <div key={`${keyPrefix}-b`} className="logo-card">
                <img src={logoImages[4].src} alt={logoImages[4].alt} />
            </div>
            <div key={`${keyPrefix}-f`} className="logo-card">
                <img src={logoImages[5].src} alt={logoImages[5].alt} />
            </div>
        </>
    );

    return (
        <div className="sponsor-bar">
            <div className="container max-w-[1350px] mx-auto px-4 sm:px-6 lg:px-8">
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-black leading-tight mb-5">
                    Các đối tác liên kết
                </h2>
                <div className="logo-marquee">
                    <div className="marquee-track">
                        {renderGroup("group1")}
                        {/* Nhóm 2 (nhân bản để tạo vòng lặp chạy vô tận) */}
                        {renderGroup("group2")}
                    </div>
                </div>
            </div>
        </div>
    );
}
