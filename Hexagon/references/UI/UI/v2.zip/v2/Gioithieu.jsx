import React, { useState, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import { useLanguageStandalone } from '../../../context/LanguageContext'
import { getSiteContents } from '../../../services/publicApi'
import '../../../locales/i18n.js'

function Gioithieu() {
    const { lang } = useLanguageStandalone();
    const { t } = useTranslation();

    const [aboutData, setAboutData] = useState({});

    useEffect(() => {
        getSiteContents(lang)
            .then(res => {
                if (res.success && Array.isArray(res.data)) {
                    const map = {};
                    res.data.forEach(item => { map[item.content_key] = item.content_value; });
                    setAboutData(map);
                }
            })
            .catch(() => setAboutData({}));
    }, [lang]);

    const c = (key, fallback) => aboutData[key] || t(key, fallback);

    return (
        <section id="gioi-thieu" className="py-16 lg:py-24 bg-[#FFFFFF]">
            <div className="container max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12 items-center">
                    <div className="w-full h-full flex items-center justify-center order-2 md:order-1 relative">
                        <div className="relative p-3 w-full">
                            <div className="absolute -inset-4 bg-gradient-to-r from-emerald-100 to-teal-100 rounded-2xl transform rotate-2"></div>
                            <img src="/assets/images/VPX16.jpg" alt="Văn phòng Hexagon" className="relative rounded-lg shadow-2xl object-cover max-h-[300px] sm:max-h-[400px] md:max-h-[500px] w-full" />
                        </div>

                        {/* Slogan Box Overlay */}
                        <div className="absolute -bottom-4 right-4 md:bottom-8 md:-right-8 bg-white p-5 rounded-xl shadow-[0_10px_40px_rgba(217,119,6,0.3)] max-w-[280px] z-10 transition-transform hover:-translate-y-2 duration-300">
                            <p className="text-sm md:text-base italic text-gray-900 font-medium leading-relaxed">
                                {c('about.slogan', '"Làm ngày, làm đêm, làm thêm ngày nghỉ ^_^"')}
                            </p>
                            <p className="text-yellow-500 text-xs mt-2 font-bold uppercase tracking-wider text-right">
                                — Hexagon Culture
                            </p>
                        </div>
                    </div>

                    <div className="text-left order-1 md:order-2">
                        <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 leading-tight">
                            {c('about.title', 'Về Hexagon')}
                        </h2>

                        <p className="text-gray-700 mb-6 text-sm sm:text-base leading-relaxed">
                            {c('about.description', 'Hexagon Corporation – Công nghệ tiên phong, nơi chúng tôi không ngừng kiến tạo và đổi mới để mang đến những giá trị vượt trội trong kỷ nguyên số. Với tầm nhìn đa chiều và khát vọng vươn tầm, Hexagon tự hào là đối tác tin cậy, đồng hành cùng bạn trên hành trình chinh phục những đỉnh cao công nghệ.')}
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-6">
                            <div className="bg-slate-50 rounded-lg p-4">
                                <h3 className="font-semibold text-[#1D6A49] text-base sm:text-lg mb-2">
                                    {c('about.mission', 'Sứ mệnh')}
                                </h3>
                                <p className="text-gray-600 text-xs sm:text-sm leading-relaxed">
                                    {c('about.missionText', 'Kiến tạo tương lai số bằng các giải pháp tiên tiến.')}
                                </p>
                            </div>
                            <div className="bg-slate-50 rounded-lg p-4">
                                <h3 className="font-semibold text-[#1D6A49] text-base sm:text-lg mb-2">
                                    {c('about.vision', 'Tầm nhìn')}
                                </h3>
                                <p className="text-gray-600 text-xs sm:text-sm leading-relaxed">
                                    {c('about.visionText', 'Trở thành biểu tượng về hệ sinh thái công nghệ đổi mới.')}
                                </p>
                            </div>
                            <div className="bg-slate-50 rounded-lg p-4">
                                <h3 className="font-semibold text-[#1D6A49] text-base sm:text-lg mb-2">
                                    {c('about.coreValues', 'Giá trị cốt lõi')}
                                </h3>
                                <p className="text-gray-600 text-xs sm:text-sm leading-relaxed">
                                    {c('about.coreValuesText', 'Đổi mới - Đồng hành - Tiên phong - Minh bạch.')}
                                </p>
                            </div>
                            <div className="bg-slate-50 rounded-lg p-4">
                                <h3 className="font-semibold text-[#1D6A49] text-base sm:text-lg mb-2">
                                    {c('about.foundation', 'Nền tảng')}
                                </h3>
                                <p className="text-gray-600 text-xs sm:text-sm leading-relaxed">
                                    {c('about.foundationText', 'Hệ sinh thái đa ngành, vững chắc và linh hoạt.')}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}

export default Gioithieu
