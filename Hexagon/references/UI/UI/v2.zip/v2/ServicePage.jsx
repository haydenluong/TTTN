import React, { useState, useEffect } from 'react';
import ServicePageTemplate from '../../components/ServicePageTemplate';
import { useLanguageStandalone } from '../../../context/LanguageContext';
import '../../../locales/i18n.js';
import { getServiceBySlug } from '../../../services/publicApi';

const UI_TEXT = {
    vi: {
        loading: 'Đang tải...',
        notFound: 'Không tìm thấy dịch vụ',
        notFoundDesc: 'Dịch vụ này không tồn tại hoặc chưa được xuất bản.',
        backHome: 'Về trang chủ',
    },
    en: {
        loading: 'Loading...',
        notFound: 'Service not found',
        notFoundDesc: 'This service does not exist or has not been published.',
        backHome: 'Back to home',
    },
};

const ServicePage = ({ serviceData, lang: langProp }) => {
    // Detect lang: prop from Astro > URL path > localStorage
    const { lang: langCtx } = useLanguageStandalone();
    const urlLang = typeof window !== 'undefined'
        ? (window.location.pathname.startsWith('/en/') ? 'en' : 'vi')
        : (langProp || 'vi');
    const lang = langProp || urlLang || langCtx || 'vi';
    const ui = UI_TEXT[lang] || UI_TEXT.vi;

    // serviceData is passed from Astro frontmatter (server-side fetched)
    const [service, setService] = useState(serviceData || null);
    const [loading, setLoading] = useState(!serviceData);
    const [error, setError] = useState(null);

    // Fallback: nếu không có data từ SSR, fetch client-side
    useEffect(() => {
        if (serviceData) return;

        const pathParts = window.location.pathname.replace(/^\//, '').replace(/\/$/, '').split('/');
        // /en/slug or /vi/slug → slug is last part
        const slug = pathParts[pathParts.length - 1];

        const fetchService = async () => {
            try {
                const response = await getServiceBySlug(slug, lang);
                if (response.success && response.data?.service) {
                    setService(response.data.service);
                } else {
                    setError(ui.notFound);
                }
            } catch (err) {
                console.error('Failed to fetch service:', err);
                setError(ui.notFound);
            } finally {
                setLoading(false);
            }
        };

        fetchService();
    }, [serviceData, lang]);

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="text-center">
                    <div className="w-12 h-12 border-4 border-gold-accent/30 border-t-gold-accent rounded-full animate-spin mx-auto mb-4"></div>
                    <p className="text-gray-400">{ui.loading}</p>
                </div>
            </div>
        );
    }

    if (error || !service) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="text-center">
                    <h2 className="text-2xl font-bold text-white mb-4">{ui.notFound}</h2>
                    <p className="text-gray-400 mb-8">{error || ui.notFoundDesc}</p>
                    <a href="/" className="px-8 py-3 bg-gold-accent hover:bg-gold-accent/80 text-black font-bold rounded-lg transition-all">
                        {ui.backHome}
                    </a>
                </div>
            </div>
        );
    }

    // Parse JSON fields from server (handle single or double-encoded JSON)
    const parseSolutionsItems = () => {
        if (!service.solutions_items) return [];
        try {
            let items = service.solutions_items;
            // console.log('[ServicePage] Raw solutions_items:', typeof items, items);
            // Parse if string
            if (typeof items === 'string') {
                items = JSON.parse(items);
                // Parse again if still string (double-encoded)
                if (typeof items === 'string') {
                    console.log('[ServicePage] Double-encoded detected, parsing again');
                    items = JSON.parse(items);
                }
            }
            const result = Array.isArray(items) ? items : [];
            // console.log('[ServicePage] Parsed solutions_items:', result);
            return result;
        } catch (err) {
            console.warn('Failed to parse solutions_items:', err);
            return [];
        }
    };

    const parseProcessItems = () => {
        if (!service.process_items) return [];
        try {
            let items = service.process_items;
            // console.log('[ServicePage] Raw process_items:', typeof items, items);
            // Parse if string
            if (typeof items === 'string') {
                items = JSON.parse(items);
                // Parse again if still string (double-encoded)
                if (typeof items === 'string') {
                    console.log('[ServicePage] Double-encoded detected, parsing again');
                    items = JSON.parse(items);
                }
            }
            const result = Array.isArray(items) ? items : [];
            // console.log('[ServicePage] Parsed process_items:', result);
            return result;
        } catch (err) {
            console.warn('Failed to parse process_items:', err);
            return [];
        }
    };

    const features = parseSolutionsItems().map(item => ({
        ...item,
        description: item.content || item.description
    }));

    const processSteps = parseProcessItems().map(item => ({
        ...item,
        description: item.content || item.description
    }));

    // Build image URL
    const getImageSrc = () => {
        if (!service.image) return null;
        let src = service.image;
        if (typeof src === 'object' && src !== null) {
            src = src.path || src.filename || null;
        } else if (typeof src === 'string' && src.trimStart().startsWith('{')) {
            try {
                const parsed = JSON.parse(src);
                src = parsed.path || parsed.filename || src;
            } catch { }
        }
        if (!src) return null;
        if (src.startsWith('http')) return src;
        const apiUrl = import.meta.env.PUBLIC_API_URL || 'http://localhost:9394/api';
        const serverBase = apiUrl.replace('/api', '');
        return src.startsWith('/') ? `${serverBase}${src}` : `${serverBase}/uploads/${src}`;
    };

    return (
        <ServicePageTemplate
            lang={lang}
            title={service.title}
            heading={service.title}
            description={service.description}
            imageSrc={getImageSrc()}
            imageAlt={service.title}
            features={features}
            processSteps={processSteps}
            ctaTitle={service.ready_title}
            ctaDescription={service.ready_description}
            solutionsTitle={service.solutions_title}
            processTitle={service.process_title}
            processDescription={service.process_description}
            ctaBtnText={service.cta_text}
            readyCta1={service.ready_cta1}
            readyCta2={service.ready_cta2}
        />
    );
};

export default ServicePage;
