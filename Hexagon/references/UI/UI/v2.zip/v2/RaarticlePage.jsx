import React, { useState, useEffect, useCallback } from 'react';
import RaarticlePageTemplate from '../../components/RaarticlePageTemplate';

// Always rely on Astro's dev/build environment variables injector
const API_URL = (typeof import.meta !== 'undefined' && import.meta.env?.PUBLIC_API_URL) || 'http://localhost:9394/api';

// Decode HTML entities
const decodeHtmlEntities = (text) => {
    if (!text) return text;
    return text
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#039;/g, "'")
        .replace(/&aacute;/g, 'á')
        .replace(/&agrave;/g, 'à')
        .replace(/&acirc;/g, 'â')
        .replace(/&atilde;/g, 'ã')
        .replace(/&eacute;/g, 'é')
        .replace(/&egrave;/g, 'è')
        .replace(/&ecirc;/g, 'ê')
        .replace(/&iacute;/g, 'í')
        .replace(/&igrave;/g, 'ì')
        .replace(/&icirc;/g, 'î')
        .replace(/&ocirc;/g, 'ô')
        .replace(/&otilde;/g, 'õ')
        .replace(/&oacute;/g, 'ó')
        .replace(/&ograve;/g, 'ò')
        .replace(/&uacute;/g, 'ú')
        .replace(/&ugrave;/g, 'ù')
        .replace(/&ucirc;/g, 'û')
        .replace(/&yacute;/g, 'ý')
        .replace(/&Aacute;/g, 'Á')
        .replace(/&Agrave;/g, 'À')
        .replace(/&Acirc;/g, 'Â')
        .replace(/&Atilde;/g, 'Ã')
        .replace(/&Eacute;/g, 'É')
        .replace(/&Egrave;/g, 'È')
        .replace(/&Ecirc;/g, 'Ê')
        .replace(/&Iacute;/g, 'Í')
        .replace(/&Igrave;/g, 'Ì')
        .replace(/&Icirc;/g, 'Î')
        .replace(/&Ocirc;/g, 'Ô')
        .replace(/&Otilde;/g, 'Õ')
        .replace(/&Oacute;/g, 'Ó')
        .replace(/&Ograve;/g, 'Ò')
        .replace(/&Uacute;/g, 'Ú')
        .replace(/&Ugrave;/g, 'Ù')
        .replace(/&Ucirc;/g, 'Û')
        .replace(/&Yacute;/g, 'Ý')
        .replace(/&Dstrok;/g, 'Đ')
        .replace(/&#272;/g, 'Đ')
        .replace(/&#273;/g, 'đ')
        .replace(/&#(\d+);/g, (match, dec) => String.fromCharCode(dec));
};

const RaarticlePage = ({ postsData, currentLanguage: initLang }) => {
    const [currentLanguage] = useState(initLang || 'vi');
    const [allPosts, setAllPosts] = useState([]);
    const [loadingPosts, setLoadingPosts] = useState(!postsData);
    const [error, setError] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const PAGE_SIZE = 12;

    const getImageSrc = (image) => {
        if (!image) return null;
        let src = image;
        if (typeof src === 'object' && src !== null) {
            src = src.path || src.filename || null;
        } else if (typeof src === 'string' && src.trimStart().startsWith('{')) {
            try {
                const parsed = JSON.parse(src);
                src = parsed.path || parsed.filename || src;
            } catch {}
        }
        if (!src) return null;
        // Strip surrounding double quotes (e.g. DB stores '"/uploads/file.jpg"')
        if (typeof src === 'string') src = src.replace(/^"|"$/g, '').trim();
        if (!src) return null;
        const serverBase = API_URL.replace('/api', '');
        if (src.startsWith('http')) return src;
        return src.startsWith('/') ? `${serverBase}${src}` : `${serverBase}/uploads/${src}`;
    };

    const buildPostHref = (post) => {
        const catSlug = currentLanguage === 'en'
            ? (post.category_slug_en || post.category_slug_vi)
            : post.category_slug_vi;
        if (catSlug && post.slug) {
            return `/${currentLanguage}/${catSlug}/${post.slug}`;
        }
        console.warn('[RaarticlePage] Post missing category slug:', post.id, post.title, 'catSlug:', catSlug);
        return `/bai-viet/${post.slug}${currentLanguage === 'en' ? '?lang=en' : ''}`;
    };

    const mapPosts = (rawPosts) => rawPosts.map(post => ({
        ...post,
        title: decodeHtmlEntities(post.title),
        description: decodeHtmlEntities(post.description),
        content: decodeHtmlEntities(post.content),
        category_name: decodeHtmlEntities(post.category_name),
        category_name_en: decodeHtmlEntities(post.category_name_en),
        imageSrc: getImageSrc(post.cover_image || post.image),
        href: buildPostHref(post),
    }));

    // Fetch posts on mount
    const fetchPosts = useCallback(async () => {
        setLoadingPosts(true);
        try {
            const params = new URLSearchParams({ lang: currentLanguage });
            const res = await fetch(`${API_URL}/posts?${params}`);
            const result = await res.json();
            if (result.success) {
                setAllPosts(mapPosts(result.data?.posts || []));
            } else {
                setError('Không thể tải danh sách bài viết');
            }
        } catch (err) {
            console.error('Failed to fetch posts:', err);
            setError('Không thể tải danh sách bài viết');
        } finally {
            setLoadingPosts(false);
        }
    }, [currentLanguage]);

    useEffect(() => {
        if (postsData) {
            setAllPosts(mapPosts(postsData));
            setLoadingPosts(false);
            return;
        }
        fetchPosts();
    }, []);

    if (error && allPosts.length === 0) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="text-center">
                    <h2 className="text-2xl font-bold text-white mb-4">Không thể tải bài viết</h2>
                    <p className="text-gray-400 mb-8">{error}</p>
                    <a href="/" className="px-8 py-3 bg-gold-accent hover:bg-gold-accent/80 text-black font-bold rounded-lg transition-all">
                        Về trang chủ
                    </a>
                </div>
            </div>
        );
    }

    const totalPages = Math.max(1, Math.ceil(allPosts.length / PAGE_SIZE));
    const safePage = Math.min(currentPage, totalPages);
    const paginatedPosts = allPosts.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);

    return (
        <RaarticlePageTemplate
            regularPosts={paginatedPosts}
            loadingPosts={loadingPosts}
            currentLanguage={currentLanguage}
            pageTitle={currentLanguage === 'en' ? 'News' : 'Tin tức'}
            pageDescription={
                currentLanguage === 'en'
                    ? 'Latest news, updates and insights from Hexagon Corporation.'
                    : 'Tin tức mới nhất, cập nhật và thông tin từ Hexagon Corporation.'
            }
            currentPage={safePage}
            totalPages={totalPages}
            onPageChange={(page) => setCurrentPage(page)}
        />
    );
};

export default RaarticlePage;
