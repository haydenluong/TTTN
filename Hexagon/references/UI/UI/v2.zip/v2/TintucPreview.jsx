import React, { useState, useEffect } from 'react';
import { useLanguageStandalone } from '../../../context/LanguageContext';

// Always rely on Astro's dev/build environment variables injector
const API_URL = (typeof import.meta !== 'undefined' && import.meta.env?.PUBLIC_API_URL) || 'http://localhost:9394/api';

const getImageUrl = (imagePath) => {
    if (!imagePath) return null;
    let src = imagePath;
    if (typeof src === 'object' && src !== null) {
        src = src.path || src.filename || null;
    } else if (typeof src === 'string' && src.trimStart().startsWith('{')) {
        try {
            const parsed = JSON.parse(src);
            src = parsed.path || parsed.filename || src;
        } catch { }
    }
    if (!src) return null;
    // Strip surrounding double quotes (e.g. DB stores '"/uploads/file.jpg"')
    if (typeof src === 'string') src = src.replace(/^"|"$/g, '').trim();
    if (!src) return null;
    if (src.startsWith('http')) return src;
    const baseUrl = API_URL.replace('/api', '');
    if (src.startsWith('/')) return `${baseUrl}${src}`;
    return `${baseUrl}/uploads/${src}`;
};

const decodeHtml = (html) => {
    if (!html) return html || '';
    return html
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#039;/g, "'")
        .replace(/&aacute;/g, 'á')
        .replace(/&agrave;/g, 'à')
        .replace(/&acirc;/g, 'â')
        .replace(/&atilde;/g, 'ã')
        .replace(/&eacute;/g, 'é')
        .replace(/&egrave;/g, 'è')
        .replace(/&ecirc;/g, 'ê')
        .replace(/&iacute;/g, 'í')
        .replace(/&igrave;/g, 'ì')
        .replace(/&icirc;/g, 'î')
        .replace(/&ocirc;/g, 'ô')
        .replace(/&otilde;/g, 'õ')
        .replace(/&oacute;/g, 'ó')
        .replace(/&ograve;/g, 'ò')
        .replace(/&uacute;/g, 'ú')
        .replace(/&ugrave;/g, 'ù')
        .replace(/&ucirc;/g, 'û')
        .replace(/&yacute;/g, 'ý')
        .replace(/&Aacute;/g, 'Á')
        .replace(/&Agrave;/g, 'À')
        .replace(/&Acirc;/g, 'Â')
        .replace(/&Atilde;/g, 'Ã')
        .replace(/&Eacute;/g, 'É')
        .replace(/&Egrave;/g, 'È')
        .replace(/&Ecirc;/g, 'Ê')
        .replace(/&Iacute;/g, 'Í')
        .replace(/&Igrave;/g, 'Ì')
        .replace(/&Icirc;/g, 'Î')
        .replace(/&Ocirc;/g, 'Ô')
        .replace(/&Otilde;/g, 'Õ')
        .replace(/&Oacute;/g, 'Ó')
        .replace(/&Ograve;/g, 'Ò')
        .replace(/&Uacute;/g, 'Ú')
        .replace(/&Ugrave;/g, 'Ù')
        .replace(/&Ucirc;/g, 'Û')
        .replace(/&Yacute;/g, 'Ý')
        .replace(/&Dstrok;/g, 'Đ')
        .replace(/&#272;/g, 'Đ')
        .replace(/&#273;/g, 'đ')
        .replace(/&#(\d+);/g, (match, dec) => String.fromCharCode(dec));
};

const truncateText = (text, maxLength = 120) => {
    if (!text) return '';
    // Remove HTML tags first, then decode entities
    const plain = decodeHtml(text.replace(/<[^>]*>/g, ''));
    return plain.length <= maxLength ? plain : plain.substring(0, maxLength) + '...';
};

const formatDate = (dateStr, lang = 'vi') => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    return date.toLocaleDateString(lang === 'vi' ? 'vi-VN' : 'en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
};

const formatTime = (dateStr) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    return date.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
};

const TEXT = {
    vi: {
        heading: 'Tin tức',
        subheading: 'Cập nhật tin tức, sự kiện và thông tin mới nhất từ Hexagon Corporation.',
        readMore: 'Xem chi tiết',
        viewAll: 'Xem tất cả bài viết',
        empty: 'Chưa có bài viết nào.',
    },
    en: {
        heading: 'News',
        subheading: 'Latest news, events and updates from Hexagon Corporation.',
        readMore: 'Read more',
        viewAll: 'View all articles',
        empty: 'No articles published yet.',
    },
};

function TintucPreview() {
    const { lang } = useLanguageStandalone();
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);
    const t = TEXT[lang] || TEXT.vi;

    useEffect(() => {
        const fetchPosts = async () => {
            setLoading(true);
            try {
                // Decode post data
                const decodePosts = (posts) => posts.map(post => ({
                    ...post,
                    title: decodeHtml(post.title),
                    description: decodeHtml(post.description),
                    content: decodeHtml(post.content),
                }));

                // Fetch featured posts first
                const featuredRes = await fetch(`${API_URL}/posts?lang=${lang}&featured=true`);
                const featuredResult = await featuredRes.json();
                const featuredPosts = featuredResult.success ? (featuredResult.data?.posts || []) : [];

                if (featuredPosts.length > 0) {
                    // Lấy tối đa 5 bài: 2 bài trên + 3 bài dưới
                    setPosts(decodePosts(featuredPosts.slice(0, 5)));
                } else {
                    // Fallback: hiển thị 5 bài viết mới nhất
                    const latestRes = await fetch(`${API_URL}/posts?lang=${lang}`);
                    const latestResult = await latestRes.json();
                    setPosts(latestResult.success ? decodePosts((latestResult.data?.posts || []).slice(0, 5)) : []);
                }
            } catch (err) {
                console.error('Failed to load posts:', err);
                setPosts([]);
            } finally {
                setLoading(false);
            }
        };
        fetchPosts();
    }, [lang]);

    const buildPostHref = (post) => {
        const catSlug = lang === 'en'
            ? (post.category_slug_en || post.category_slug_vi)
            : post.category_slug_vi;
        if (catSlug && post.slug) {
            return `/${lang}/${catSlug}/${post.slug}`;
        }
        // Fallback for posts without category slug
        console.warn('[TintucPreview] Post missing category slug:', post.id, post.title, 'catSlug:', catSlug);
        return `/bai-viet/${post.slug}${lang === 'en' ? '?lang=en' : ''}`;
    };

    return (
        <section id="tin-tuc" className="py-10 md:py-16 bg-white">
            <div className="container max-w-[1350px] mx-auto px-4 sm:px-6 lg:px-8 w-full">

                {/* Section header */}
                <div className="text-center mb-8 md:mb-12">
                    <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-black leading-tight">
                        {t.heading}
                    </h2>
                    <p className="text-gray-700 mt-2 text-sm sm:text-base leading-relaxed px-4">
                        {t.subheading}
                    </p>
                    <div className="w-16 h-1 bg-yellow-400 mx-auto mt-4 rounded-full"></div>
                </div>

                {/* Loading */}
                {loading ? (
                    <div className="flex justify-center items-center py-16">
                        <div className="w-10 h-10 border-4 border-yellow-400 border-t-transparent rounded-full animate-spin"></div>
                    </div>
                ) : posts.length === 0 ? (
                    <p className="text-center text-gray-500">{t.empty}</p>
                ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-6 lg:gap-8">
                        {posts.map((post, index) => {
                            const publishedDate = post.published_date || post.created_at;
                            const imgSrc = getImageUrl(post.cover_image || post.image);
                            const href = buildPostHref(post);
                            // 2 bài đầu (hàng trên): chiếm 3/6 cột => 2 cột trên desktop
                            // 3 bài sau (hàng dưới): chiếm 2/6 cột => 3 cột trên desktop
                            const spanClass = index < 2 ? 'lg:col-span-3' : 'lg:col-span-2';

                            return (
                                <a
                                    key={post.id || post.slug}
                                    href={href}
                                    className={`${spanClass} group bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden
                                               flex flex-col transition-all hover:shadow-md hover:border-yellow-400/50`}
                                >
                                    {/* Thumbnail - chiều cao cố định để các card bằng nhau */}
                                    {imgSrc ? (
                                        <div className="overflow-hidden h-48 sm:h-52">
                                            <img
                                                src={imgSrc}
                                                alt={post.title}
                                                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
                                            />
                                        </div>
                                    ) : (
                                        <div className="h-48 sm:h-52 bg-gradient-to-br from-gray-100 to-slate-200 flex items-center justify-center">
                                            <svg className="w-10 h-10 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5"
                                                    d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14
                                                       M8 10a2 2 0 100-4 2 2 0 000 4z" />
                                            </svg>
                                        </div>
                                    )}

                                    {/* Content */}
                                    <div className="p-5 flex flex-col flex-1">
                                        <h3 className="text-base font-bold text-gray-900 mb-2 line-clamp-2
                                                        group-hover:text-yellow-600 transition-colors leading-snug">
                                            {post.title}
                                        </h3>

                                        <p className="text-gray-600 text-sm leading-relaxed line-clamp-3 flex-1 mb-4">
                                            {post.description ? post.description : truncateText(post.content)}
                                        </p>

                                        {/* Date + time row */}
                                        <div className="flex items-center justify-between pt-3 border-t border-gray-100 mt-auto">
                                            <div className="flex items-center gap-3 text-xs text-gray-400">
                                                <span className="flex items-center gap-1">
                                                    <svg className="w-3 h-3 text-yellow-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"
                                                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                                    </svg>
                                                    {formatDate(publishedDate, lang)}
                                                </span>
                                                {/* <span className="flex items-center gap-1">
                                                    <svg className="w-3 h-3 text-yellow-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"
                                                            d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                    </svg>
                                                    {formatTime(publishedDate)}
                                                </span> */}
                                            </div>
                                            <span className="text-yellow-600 text-xs font-semibold group-hover:underline">
                                                {t.readMore} →
                                            </span>
                                        </div>
                                    </div>
                                </a>
                            );
                        })}
                    </div>
                )}

                {/* View all button */}
                {!loading && posts.length > 0 && (
                    <div className="text-center mt-10">
                        <a
                            href={`/${lang}/bai-viet`}
                            className="inline-flex items-center gap-2 px-8 py-3
                                       text-white font-bold rounded-lg
                                       bg-gradient-to-r from-[#008374] to-[#89BA16]
                                       hover:from-[#007164] hover:to-[#78A614]
                                       hover:ring-2 hover:ring-green-500
                                       transition-all duration-200"
                        >
                            {t.viewAll}
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                            </svg>
                        </a>
                    </div>
                )}
            </div>
        </section>
    );
}

export default TintucPreview;