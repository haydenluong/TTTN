import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useLanguageStandalone } from '../../../context/LanguageContext';
import '../../../locales/i18n.js';
import { getFooter } from '../../../services/publicApi';

const DEFAULT_LINKS = {
  menu_home: '/',
  menu_about: '/gioi-thieu',
  menu_services: '/dich-vu',
  menu_support: '/ho-tro',
  menu_contact: '/lien-he',
};

const isExternal = (url) => /^https?:\/\//i.test(url);

const NavLink = ({ href, children }) => (
  <a
    href={href || '#'}
    {...(isExternal(href) ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
    className="text-gray-200 hover:text-white transition-colors"
  >
    {children}
  </a>
);

const Footer = () => {
  useLanguageStandalone();
  const { t } = useTranslation();
  const [links, setLinks] = useState(DEFAULT_LINKS);
  const [footerInfo, setFooterInfo] = useState({
    company_name: '',
    company_description: '',
    address: '',
    email: '',
    phone: '',
    copyright: ''
  });

  useEffect(() => {
    getFooter()
      .then(res => {
        if (res.success && res.data?.length > 0) {
          const d = res.data[0];
          setLinks({
            menu_home: d.menu_home || DEFAULT_LINKS.menu_home,
            menu_about: d.menu_about || DEFAULT_LINKS.menu_about,
            menu_services: d.menu_services || DEFAULT_LINKS.menu_services,
            menu_support: d.menu_support || DEFAULT_LINKS.menu_support,
            menu_contact: d.menu_contact || DEFAULT_LINKS.menu_contact,
          });
          setFooterInfo({
            company_name: d.company_name,
            company_description: d.company_description,
            address: d.address,
            email: d.email,
            phone: d.phone,
            copyright: d.copyright
          });
        }
      })
      .catch(() => { });
  }, []);

  return (
    <footer className="w-full  pb-3 bg-[#0D5939] border-t border-[#0D5939]">
      <div className="mt-6 text-center">
        <p className="text-gray-400 text-sm">
          {footerInfo.copyright ? (
            footerInfo.copyright
          ) : (
            <>{t('footer.copyright', 'Copyright 2026 ©')} <span className="text-gray-300 font-medium">Hexagon Corporation</span>. {t('footer.allRights', 'All rights reserved.')}</>
          )}
        </p>
      </div>
    </footer>
  );
};

export default Footer;
