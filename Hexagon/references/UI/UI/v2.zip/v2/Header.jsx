import React, { useState, useEffect } from 'react';
import { useLanguageStandalone } from '../../../context/LanguageContext';
import { useTranslation } from 'react-i18next';
import '../../../locales/i18n.js';
import { getPublicPostByLangSlug, getServiceBySlug } from '../../../services/publicApi';


const ViFlagIcon = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 480" className={className}>
    <defs><clipPath id="vn-a"><path fillOpacity=".7" d="M-85.3 0h682.6v512H-85.3z" /></clipPath></defs>
    <g fillRule="evenodd" clipPath="url(#vn-a)" transform="translate(80)scale(.9375)">
      <path fill="#da251d" d="M-128 0h768v512h-768z" />
      <path fill="#ff0" d="M349.6 381 260 314.3l-89 67.3L204 272l-89-67.7 110.1-1 34.2-109.4L294 203l110.1.1-88.5 68.4 33.9 109.6z" />
    </g>
  </svg>
);

const EnFlagIcon = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 480" className={className}>
    <path fill="#012169" d="M0 0h640v480H0z" />
    <path fill="#FFF" d="m75 0 244 181L562 0h78v62L400 241l240 178v61h-80L320 301 81 480H0v-60l239-178L0 64V0z" />
    <path fill="#C8102E" d="m424 281 216 159v40L369 281zm-184 20 6 35L54 480H0zM640 0v3L391 191l2-44L590 0zM0 0l239 176h-60L0 42z" />
    <path fill="#FFF" d="M241 0v480h160V0zM0 160v160h640V160z" />
    <path fill="#C8102E" d="M0 193v96h640v-96zM273 0v480h96V0z" />
  </svg>
);

// Mock category service temporarily to fix compilation
const categoryService = {
  getAllCategoriesHeader: async () => ({ success: true, data: [] })
};

const Header = ({ currentPage = 'home', topTextBlack = false }) => {
  const { lang, setLang } = useLanguageStandalone();
  const { t } = useTranslation();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [categories, setCategories] = useState([]);
  const [isNewsDropdownOpen, setIsNewsDropdownOpen] = useState(false);
  const [hoveredCategory, setHoveredCategory] = useState(null);

  const handleLangSwitch = async (_, newLang) => {
    if (newLang === lang) return;
    setLang(newLang);

    if (typeof window !== 'undefined') {
      const pathname = window.location.pathname;

      // Pattern 1: SEO post URL  /:lang/:categorySlug/:postSlug
      const postUrlMatch = pathname.match(/^\/(vi|en)\/([^/]+)\/([^/]+)$/);
      if (postUrlMatch) {
        const [, , , currentPostSlug] = postUrlMatch;

        // Read sibling data from inline JSON injected by the Astro page
        try {
          const metaEl = document.getElementById('post-meta');
          if (metaEl) {
            const meta = JSON.parse(metaEl.textContent || '{}');
            if (meta.siblingUrl && meta.siblingLang === newLang) {
              window.location.href = meta.siblingUrl;
              return;
            }
            // No sibling translation — redirect to listing
            window.location.href = `/${newLang}/bai-viet`;
            return;
          }
        } catch (_) { }

        // Fallback: fetch sibling from API
        try {
          const response = await getPublicPostByLangSlug(lang, currentPostSlug);
          if (response.success && response.data?.post) {
            const post = response.data.post;
            const siblingSlug = post.sibling_slug;
            const siblingCatSlug = newLang === 'en'
              ? (post.category_slug_en || post.category_slug_vi)
              : post.category_slug_vi;
            if (siblingSlug && siblingCatSlug) {
              window.location.href = `/${newLang}/${siblingCatSlug}/${siblingSlug}`;
              return;
            }
          }
        } catch (error) {
          console.error('Error fetching post sibling for lang switch:', error);
        }

        // No translation found — go to listing
        window.location.href = `/${newLang}/bai-viet`;
        return;
      }

      // Pattern 2: Service page  /:lang/:serviceSlug
      const langPrefixMatch = pathname.match(/^\/(vi|en)(\/([^/]+))?$/);
      if (langPrefixMatch) {
        const currentLang = langPrefixMatch[1];
        const currentSlug = langPrefixMatch[3];

        if (!currentSlug) {
          // Không có trang /vi hay /en index — về trang chủ
          window.location.href = '/';
        }

        try {
          const response = await getServiceBySlug(currentSlug, currentLang);

          if (response.success && response.data?.service) {
            const translations = response.data.service.translations || [];
            const targetTranslation = translations.find(t => t.lang === newLang);

            if (targetTranslation) {
              const linkVal = targetTranslation.link
                ? targetTranslation.link.replace(/^\//, '')
                : null;
              const targetPath = linkVal || targetTranslation.slug;
              if (targetPath) {
                window.location.href = `/${newLang}/${targetPath}`;
                return;
              }
            }
          }
        } catch (error) {
          console.error('Lỗi khi tìm slug dịch qua ngôn ngữ mới:', error);
        }

        // Không tìm thấy translation — về trang chủ
        window.location.href = '/';
      }
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const loadCategories = async () => {
      try {
        const data = await categoryService.getAllCategoriesHeader();
        setCategories(data || []);
      } catch (err) {
        console.error('Error loading categories:', err);
      }
    };
    loadCategories();
  }, []);
  useEffect(() => {
    const handleClickOutside = (event) => {
      const menuBtn = document.getElementById('menu-btn');
      const mobileMenu = document.getElementById('mobile-menu');

      if (mobileMenu && !mobileMenu.contains(event.target) && menuBtn && !menuBtn.contains(event.target)) {
        setIsMobileMenuOpen(false);
      }
    };

    if (isMobileMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isMobileMenuOpen]);

  const handleAnchorClick = (e, targetId) => {
    e.preventDefault();
    const targetElement = document.querySelector(targetId);
    if (targetElement) {
      targetElement.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  const baseUrl = currentPage === 'home' ? '' : '/';
  const logoTextClass = !isScrolled && topTextBlack ? 'text-gray-900' : 'text-white';
  const linkBaseClass = !isScrolled && topTextBlack ? 'text-gray-700 hover:text-gold-accent' : 'text-gray-300 hover:text-gold-accent';
  const mobileLinkClass = 'block py-3 px-6 text-base font-medium text-gray-800 hover:text-[#d97706] hover:bg-gray-50';

  return (
    <header
      id="navbar"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'nav-scrolled' : 'bg-[#1A6B49]'
        }`}
    >
      <nav
        className="mx-auto py-2 flex justify-between items-center"
        style={{ paddingInline: 'clamp(1.5rem, 5vw, 5rem)' }}
      >
        <div className="flex items-center space-x-2">
          <div className="w-16 h-16">
            <a href="/" className="block">
              <img src="/assets/images/logo-hhc.png" alt="Hexagon Logo" />
            </a>
          </div>
          <span className={`text-xl font-bold ${logoTextClass}`}>HEXAGON</span>
        </div>

        <div className="hidden md:flex items-center space-x-8">
          <a href={`${baseUrl}#trang-chu`} className={`${linkBaseClass} transition`}
            onClick={(e) => currentPage === 'trang-chu' && handleAnchorClick(e, '#trang-chu')}>
            {t('nav.home', 'Trang chủ')}
          </a>
          <a href={`${baseUrl}#gioi-thieu`} className={`${linkBaseClass} transition`}
            onClick={(e) => currentPage === 'trang-chu' && handleAnchorClick(e, '#gioi-thieu')}>
            {t('nav.about', 'Giới thiệu')}
          </a>
          <a href={`${baseUrl}#dich-vu`} className={`${linkBaseClass} transition`}
            onClick={(e) => currentPage === 'trang-chu' && handleAnchorClick(e, '#dich-vu')}>
            {t('nav.services', 'Dịch vụ')}
          </a>

          {/* Hỗ trợ */}
          <a href="https://support.hexagon.xyz/" target="_blank" rel="noopener noreferrer" className={`${linkBaseClass} transition`}>
            {t('nav.support', 'Hỗ trợ')}
          </a>

          <a href={`${baseUrl}#lien-he`} className={`${linkBaseClass} transition`}
            onClick={(e) => currentPage === 'trang-chu' && handleAnchorClick(e, '#lien-he')}>
            {t('nav.contact', 'Liên hệ')}
          </a>
          <div className="lang-switcher flex items-center gap-2 ml-4">
            <button
              type="button"
              title="Tiếng Việt"
              onClick={() => handleLangSwitch(null, 'vi')}
              style={{ opacity: lang === 'vi' ? 1 : 0.45, transition: 'opacity 0.2s', cursor: 'pointer', background: 'none', border: 'none', padding: 0 }}
            >
              <ViFlagIcon className="w-6 h-4 object-cover rounded-sm" />
            </button>
            <button
              type="button"
              title="English"
              onClick={() => handleLangSwitch(null, 'en')}
              style={{ opacity: lang === 'en' ? 1 : 0.45, transition: 'opacity 0.2s', cursor: 'pointer', background: 'none', border: 'none', padding: 0 }}
            >
              <EnFlagIcon className="w-6 h-4 object-cover rounded-sm" />
            </button>
          </div>
        </div>

        <div className="md:hidden">
          <button id="menu-btn" className={`${!isScrolled && topTextBlack ? 'text-gray-900' : 'text-white'} focus:outline-none`} onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7"></path>
            </svg>
          </button>
        </div>
      </nav>

      <div id="mobile-menu" className={`${isMobileMenuOpen ? 'block' : 'hidden'} md:hidden fixed top-20 left-0 w-full bg-white shadow-2xl border-t border-gray-100 z-40 transition-all pb-4 py-2`}>
        <a href={`${baseUrl}#trang-chu`} className={mobileLinkClass} onClick={(e) => currentPage === 'trang-chu' && handleAnchorClick(e, '#trang-chu')}>
          {t('nav.home', 'Trang chủ')}
        </a>
        <a href={`${baseUrl}#gioi-thieu`} className={mobileLinkClass} onClick={(e) => currentPage === 'trang-chu' && handleAnchorClick(e, '#gioi-thieu')}>
          {t('nav.about', 'Giới thiệu')}
        </a>
        <a href={`${baseUrl}#dich-vu`} className={mobileLinkClass} onClick={(e) => currentPage === 'trang-chu' && handleAnchorClick(e, '#dich-vu')}>
          {t('nav.services', 'Dịch vụ')}
        </a>
        <a href="https://support.hexagon.xyz/" target="_blank" rel="noopener noreferrer" className={mobileLinkClass}>
          {t('nav.support', 'Hỗ trợ')}
        </a>
        <a href={`${baseUrl}#lien-he`} className={mobileLinkClass} onClick={(e) => currentPage === 'trang-chu' && handleAnchorClick(e, '#lien-he')}>
          {t('nav.contact', 'Liên hệ')}
        </a>
        <div className="lang-switcher flex items-center gap-4 px-6 pt-4 mt-2 pb-2 border-t border-gray-100">
          <button
            type="button"
            title="Tiếng Việt"
            onClick={() => handleLangSwitch(null, 'vi')}
            style={{ opacity: lang === 'vi' ? 1 : 0.45, transition: 'opacity 0.2s', cursor: 'pointer', background: 'none', border: 'none', padding: 0 }}
          >
            <ViFlagIcon className="w-6 h-4 object-cover rounded-sm" />
          </button>
          <button
            type="button"
            title="English"
            onClick={() => handleLangSwitch(null, 'en')}
            style={{ opacity: lang === 'en' ? 1 : 0.45, transition: 'opacity 0.2s', cursor: 'pointer', background: 'none', border: 'none', padding: 0 }}
          >
            <EnFlagIcon className="w-6 h-4 object-cover rounded-sm" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
