import React, { useState, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import { useLanguageStandalone } from '../../../context/LanguageContext'
import ServicesTypewriter from '../../components/ServicesTypewriter'
import HeroBackground3D from '../../components/HeroBackground3D'
import { getSiteContents } from '../../../services/publicApi'
import '../../../locales/i18n.js'

function Trangchu() {
    // useLanguageStandalone để lắng nghe event và trigger re-render khi đổi ngôn ngữ
    const { lang } = useLanguageStandalone();
    const { t } = useTranslation();

    // Hero data từ DB (flat key-value theo language)
    const [heroData, setHeroData] = useState({});

    useEffect(() => {
        getSiteContents(lang)
            .then(res => {
                if (res.success && Array.isArray(res.data)) {
                    // Chuyển mảng [{content_key, content_value}] thành object lookup
                    const map = {};
                    res.data.forEach(item => { map[item.content_key] = item.content_value; });
                    setHeroData(map);
                }
            })
            .catch(() => {
                // Nếu API lỗi → vẫn hiển thị fallback từ t()
                setHeroData({});
            });
    }, [lang]);

    // Helper: đọc từ DB trước, fallback về t()
    const c = (key, fallback) => heroData[key] || t(key, fallback);

    return (
        <section
            id="trang-chu"
            className="fullscreen-section relative flex items-center pt-24 pb-12 overflow-hidden bg-gradient-to-br from-[#135237] via-[#196B49] to-[#41b67d]"
            style={{ backgroundColor: '#196849' }}
        >
            {/* <BackgroundVideo /> */}
            <div className="container max-w-[1450px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">

                    {/* Left Column - Text Content */}
                    <div className="flex flex-col items-start text-left space-y-6 lg:pr-8">
                        {/* Badge */}
                        <div className="inline-block px-4 py-1.5 rounded-full border border-yellow-500/50 bg-yellow-500/10 backdrop-blur-sm">
                            <span className="text-yellow-500 text-sm font-bold tracking-wider uppercase">
                                {c('hero.badge', 'Công nghệ tương lai')}
                            </span>
                        </div>

                        {/* Heading - dòng 1 luân phiên các dịch vụ, dòng 2 là brand "HEXAGON Solutions" */}
                        <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white leading-[1.15] tracking-tight">
                            <ServicesTypewriter key={lang} /> <br />
                            <span
                                className="inline-block mt-2"
                                style={{
                                    background: 'linear-gradient(135deg, #ffffff 0%, #a8e6d8 55%, #F7931E 100%)',
                                    WebkitBackgroundClip: 'text',
                                    backgroundClip: 'text',
                                    WebkitTextFillColor: 'transparent',
                                    color: 'transparent',
                                }}
                            >
                                {c('hero.title2', 'HEXAGON Solutions')}
                            </span>
                        </h1>

                        {/* Description */}
                        <p className="text-gray-200 text-base sm:text-lg leading-relaxed max-w-xl">
                            {c('hero.description', 'Hexagon kiến tạo các giải pháp chuyển đổi số toàn diện, từ phần mềm, AI đến an ninh mạng, giúp doanh nghiệp bứt phá trong kỷ nguyên số.')}
                        </p>

                        {/* Buttons */}
                        <div className="flex flex-col sm:flex-row gap-4 pt-4 w-full sm:w-auto">
                            <a href="#dich-vu" className="px-8 py-3.5 bg-[linear-gradient(to_right,#ff9902,#f2d337)] hover:brightness-110 !text-white rounded-lg transition-all shadow-lg text-center shadow-yellow-500/30">
                                {c('hero.exploreBtn', 'Khám phá Dịch vụ')}
                            </a>
                            <a href="#lien-he" className="px-8 py-3.5 bg-white/10 hover:bg-white/20 border border-white/20 !text-white  rounded-lg transition-colors backdrop-blur-sm text-center">
                                {c('hero.contactBtn', 'Liên hệ Tư vấn')}
                            </a>
                        </div>
                    </div>

                    {/* Right Column - Mạng nơ-ron 3D (thay cho Ecosystem Diagram cũ) */}
                    <div className="relative w-full flex justify-center">
                        <div className="relative w-full max-w-none aspect-square">
                            {/* <HeroBackground3D /> */}
                            <img
                                src="https://metik.vn/wp-content/uploads/2026/06/globalmyc.webp"
                                alt="Hexagon Global"
                                className="w-full h-full object-contain"
                                loading="lazy"
                            />
                        </div>
                    </div>
                </div>
            </div>

            {/* Scroll Indicator */}
            <div className="absolute inset-x-0 bottom-8 flex justify-center animate-bounce z-20">
                <a href="#gioi-thieu" className="text-gray-300 hover:text-white flex flex-col items-center gap-1 transition-colors">
                    <span className="text-sm font-medium tracking-wide">
                        {c('hero.scrollDown', 'Cuộn xuống để khám phá')}
                    </span>
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                    </svg>
                </a>
            </div>
        </section>
    )
}

export default Trangchu
