import React from 'react';
import ServicesMiniSlider from '../../islands/ServicesMiniSlider';

const formatDate = (dateStr, lang = 'vi') => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    return date.toLocaleDateString(lang === 'vi' ? 'vi-VN' : 'en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
    });
};

const formatTime = (dateStr) => {
    if (!dateStr) return '';
    if (!dateStr.includes('T') && !dateStr.includes(' ')) return '';
    const date = new Date(dateStr);
    return date.toLocaleTimeString('vi-VN', {
        hour: '2-digit',
        minute: '2-digit',
    });
};

const decodeHtmlEntities = (text) => {
    if (!text) return '';
    return text
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#039;/g, "'")
        .replace(/&aacute;/g, 'á')
        .replace(/&agrave;/g, 'à')
        .replace(/&acirc;/g, 'â')
        .replace(/&atilde;/g, 'ã')
        .replace(/&eacute;/g, 'é')
        .replace(/&egrave;/g, 'è')
        .replace(/&ecirc;/g, 'ê')
        .replace(/&iacute;/g, 'í')
        .replace(/&igrave;/g, 'ì')
        .replace(/&icirc;/g, 'î')
        .replace(/&ocirc;/g, 'ô')
        .replace(/&otilde;/g, 'õ')
        .replace(/&oacute;/g, 'ó')
        .replace(/&ograve;/g, 'ò')
        .replace(/&uacute;/g, 'ú')
        .replace(/&ugrave;/g, 'ù')
        .replace(/&ucirc;/g, 'û')
        .replace(/&yacute;/g, 'ý')
        .replace(/&Aacute;/g, 'Á')
        .replace(/&Agrave;/g, 'À')
        .replace(/&Acirc;/g, 'Â')
        .replace(/&Atilde;/g, 'Ã')
        .replace(/&Eacute;/g, 'É')
        .replace(/&Egrave;/g, 'È')
        .replace(/&Ecirc;/g, 'Ê')
        .replace(/&Iacute;/g, 'Í')
        .replace(/&Igrave;/g, 'Ì')
        .replace(/&Icirc;/g, 'Î')
        .replace(/&Ocirc;/g, 'Ô')
        .replace(/&Otilde;/g, 'Õ')
        .replace(/&Oacute;/g, 'Ó')
        .replace(/&Ograve;/g, 'Ò')
        .replace(/&Uacute;/g, 'Ú')
        .replace(/&Ugrave;/g, 'Ù')
        .replace(/&Ucirc;/g, 'Û')
        .replace(/&Yacute;/g, 'Ý')
        .replace(/&Dstrok;/g, 'Đ')
        .replace(/&#272;/g, 'Đ')
        .replace(/&#273;/g, 'đ')
        .replace(/&#(\d+);/g, (match, dec) => String.fromCharCode(dec));
};

const truncateText = (text, maxLength = 140) => {
    if (!text) return '';
    // Remove HTML tags first, then decode entities
    const plain = decodeHtmlEntities(text.replace(/<[^>]*>/g, ''));
    return plain.length <= maxLength ? plain : plain.substring(0, maxLength) + '...';
};

// ── Article card ──────────────────────────────────────────────────────────────

const ArticleCard = ({ post, currentLanguage }) => {
    const publishedDate = post.published_date || post.created_at;

    return (
        <a
            href={post.href}
            className="group bg-white border border-gray-200 shadow-sm rounded-xl overflow-hidden
                       transition-all hover:shadow-md hover:border-gold-accent/40 flex flex-col"
        >
            {post.imageSrc ? (
                <div className="relative overflow-hidden aspect-[16/9]">
                    <img
                        src={post.imageSrc}
                        alt={post.title}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                    />
                    {post.is_featured === 1 && (
                        <span className="absolute top-3 left-3 bg-[#f59e0b] text-white text-xs font-bold px-3 py-1 rounded-full">
                            {currentLanguage === 'en' ? 'Featured' : 'Nổi bật'}
                        </span>
                    )}
                </div>
            ) : (
                <div className="aspect-[16/9] bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
                    <svg className="w-12 h-12 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5"
                            d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14
                               M8 10a2 2 0 100-4 2 2 0 000 4z" />
                    </svg>
                </div>
            )}

            <div className="p-4 flex flex-col flex-1">
                {post.category_name && (
                    <span className="inline-block text-[11px] font-semibold text-[#f59e0b] bg-yellow-50 border border-yellow-200 rounded-full px-2 py-0.5 mb-2 w-fit">
                        {currentLanguage === 'en' ? (post.category_name_en || post.category_name) : post.category_name}
                    </span>
                )}
                <h2 className="text-base font-bold text-gray-900 mb-2 line-clamp-2 group-hover:text-[#d97706] transition-colors leading-snug">
                    {post.title}
                </h2>

                <p className="text-gray-600 text-xs leading-relaxed line-clamp-2 flex-1 mb-3">
                    {truncateText(post.description) || truncateText(post.content)}
                </p>

                <div className="flex items-center justify-between pt-3 border-t border-gray-100 mt-auto">
                    <div className="flex items-center gap-2 text-[11px] text-gray-400">
                        <span className="flex items-center gap-1">
                            <svg className="w-3 h-3 text-gold-accent flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"
                                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                            {formatDate(publishedDate, currentLanguage)}
                        </span>
                        {formatTime(publishedDate) && (
                            <span className="flex items-center gap-1">
                                <svg className="w-3 h-3 text-gold-accent flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"
                                        d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                {formatTime(publishedDate)}
                            </span>
                        )}
                    </div>

                    <span className="text-[#f59e0b] text-[11px] font-semibold group-hover:underline">
                        {currentLanguage === 'en' ? 'Read more →' : 'Xem thêm →'}
                    </span>
                </div>
            </div>
        </a>
    );
};

// ── Featured article (large card at top) ─────────────────────────────────────

const FeaturedArticleCard = ({ post, currentLanguage }) => {
    const publishedDate = post.published_date || post.created_at;

    return (
        <a
            href={post.href}
            className="group bg-white border border-gray-200 shadow-sm rounded-xl overflow-hidden
                       transition-all hover:shadow-md hover:border-gold-accent/40
                       grid md:grid-cols-2 gap-0 mb-8"
        >
            {post.imageSrc ? (
                <div className="relative overflow-hidden aspect-[16/9] md:aspect-auto">
                    <img
                        src={post.imageSrc}
                        alt={post.title}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.02]"
                    />
                    <span className="absolute top-4 left-4 bg-[#f59e0b] text-white text-xs font-bold px-3 py-1.5 rounded-full">
                        {currentLanguage === 'en' ? 'Featured' : 'Nổi bật'}
                    </span>
                </div>
            ) : (
                <div className="aspect-[16/9] md:aspect-auto bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
                    <svg className="w-16 h-16 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5"
                            d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14
                               M8 10a2 2 0 100-4 2 2 0 000 4z" />
                    </svg>
                </div>
            )}

            <div className="p-8 flex flex-col justify-center">
                <div className="flex items-center gap-3 text-xs text-gray-400 mb-4">
                    <span className="flex items-center gap-1">
                        <svg className="w-3.5 h-3.5 text-gold-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"
                                d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        {formatDate(publishedDate, currentLanguage)}
                    </span>
                    {formatTime(publishedDate) && (
                        <span className="flex items-center gap-1">
                            <svg className="w-3.5 h-3.5 text-gold-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"
                                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            {formatTime(publishedDate)}
                        </span>
                    )}
                </div>

                <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-4 leading-tight group-hover:text-[#d97706] transition-colors">
                    {post.title}
                </h2>

                <p className="text-gray-600 leading-relaxed line-clamp-4 mb-6">
                    {post.description ? post.description : truncateText(post.content, 220)}
                </p>

                <span className="inline-flex items-center gap-2 text-[#f59e0b] font-semibold group-hover:gap-3 transition-all">
                    {currentLanguage === 'en' ? 'Read more' : 'Xem chi tiết'}
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                    </svg>
                </span>
            </div>
        </a>
    );
};

// ── Horizontal Post Card (list view) ────────────────────────────────────────

const HorizontalPostCard = ({ post, currentLanguage }) => {
    const publishedDate = post.published_date || post.created_at;
    return (
        <a
            href={post.href}
            className="group flex gap-4 bg-white border border-gray-200 shadow-sm rounded-xl overflow-hidden
                       transition-all hover:shadow-md hover:border-gold-accent/40 p-4"
        >
            {/* Thumbnail */}
            <div className="w-32 h-24 flex-shrink-0 rounded-lg overflow-hidden bg-gray-100">
                {post.imageSrc ? (
                    <img
                        src={post.imageSrc}
                        alt={post.title}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.05]"
                    />
                ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-100 to-gray-200">
                        <svg className="w-8 h-8 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5"
                                d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14M8 10a2 2 0 100-4 2 2 0 000 4z" />
                        </svg>
                    </div>
                )}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0 flex flex-col justify-between py-0.5">
                <div>
                    {post.category_name && (
                        <span className="inline-block text-xs font-semibold text-[#f59e0b] bg-yellow-50 border border-yellow-200 rounded-full px-2 py-0.5 mb-1.5 w-fit">
                            {currentLanguage === 'en' ? (post.category_name_en || post.category_name) : post.category_name}
                        </span>
                    )}
                    <h2 className="text-sm font-bold text-gray-900 line-clamp-2 group-hover:text-[#d97706] transition-colors leading-snug">
                        {post.title}
                    </h2>
                </div>
                <div className="flex items-center justify-between mt-2">
                    <span className="text-xs text-gray-400 flex items-center gap-1">
                        <svg className="w-3 h-3 text-gold-accent flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"
                                d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        {formatDate(publishedDate, currentLanguage)}
                    </span>
                    <span className="text-[#f59e0b] text-xs font-semibold group-hover:underline">
                        {currentLanguage === 'en' ? 'Read more →' : 'Xem thêm →'}
                    </span>
                </div>
            </div>
        </a>
    );
};

// ── Pagination controls ───────────────────────────────────────────────────────

const Pagination = ({ currentPage, totalPages, onPageChange }) => {
    if (totalPages <= 1) return null;

    const getPageNumbers = () => {
        if (totalPages <= 7) return Array.from({ length: totalPages }, (_, i) => i + 1);
        const pages = [];
        if (currentPage <= 4) {
            pages.push(1, 2, 3, 4, 5, '...', totalPages);
        } else if (currentPage >= totalPages - 3) {
            pages.push(1, '...', totalPages - 4, totalPages - 3, totalPages - 2, totalPages - 1, totalPages);
        } else {
            pages.push(1, '...', currentPage - 1, currentPage, currentPage + 1, '...', totalPages);
        }
        return pages;
    };

    return (
        <div className="flex items-center justify-center gap-1 mt-8 pt-6 border-t border-gray-200">
            <button
                onClick={() => onPageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className="w-8 h-8 flex items-center justify-center rounded border border-gray-300 text-gray-500 hover:bg-yellow-50 hover:border-yellow-400 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
            </button>
            {getPageNumbers().map((p, i) =>
                p === '...' ? (
                    <span key={`ellipsis-${i}`} className="w-8 h-8 flex items-center justify-center text-gray-400 text-sm">…</span>
                ) : (
                    <button
                        key={p}
                        onClick={() => onPageChange(p)}
                        className={`w-8 h-8 flex items-center justify-center rounded border text-sm font-medium transition-colors ${currentPage === p
                            ? 'bg-yellow-400 border-yellow-400 text-white'
                            : 'border-gray-300 text-gray-700 hover:bg-yellow-50 hover:border-yellow-400'
                            }`}
                    >
                        {p}
                    </button>
                )
            )}
            <button
                onClick={() => onPageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="w-8 h-8 flex items-center justify-center rounded border border-gray-300 text-gray-500 hover:bg-yellow-50 hover:border-yellow-400 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
            </button>
        </div>
    );
};

// ── Main template ─────────────────────────────────────────────────────────────

const RaarticlePageTemplate = ({
    regularPosts = [],
    loadingPosts = false,
    currentLanguage = 'vi',
    pageTitle,
    pageDescription,
    currentPage = 1,
    totalPages = 1,
    onPageChange,
}) => {
    const hasAny = regularPosts.length > 0;

    return (
        <div className="antialiased text-base bg-[#F8FAFC] min-h-screen article-page-wrapper">
            <main className="pt-28 md:pt-32">
                <div className="container mx-auto px-6 py-6">

                    {/* Breadcrumb */}
                    <section className="text-left mb-8 text-base">
                        <nav className="text-sm text-gray-400 flex items-center gap-1 flex-wrap">
                            <a href="/" className="hover:text-gold-accent transition-colors">
                                {currentLanguage === 'en' ? 'Home' : 'Trang chủ'}
                            </a>
                            <span className="mx-1 text-gray-300">&gt;</span>
                            <span className="text-gray-700 font-medium">{pageTitle}</span>
                        </nav>
                    </section>

                    {/* Two-column layout */}
                    <div className="flex flex-col lg:flex-row gap-8 items-start">

                        {/* Left column – heading + posts list */}
                        <div className="flex-1 min-w-0">
                            {/* Page heading */}
                            <section className="mb-10">
                                <h1 className="text-4xl lg:text-5xl font-bold text-yellow-500 mb-3 leading-tight">
                                    {pageTitle}
                                </h1>
                                <p className="max-w-2xl text-lg text-gray-700 leading-relaxed">
                                    {pageDescription}
                                </p>
                                <div className="w-16 h-1 bg-gold-accent mt-5 rounded-full"></div>
                            </section>

                            {loadingPosts ? (
                                <div className="flex justify-center items-center py-24">
                                    <div className="w-12 h-12 border-4 border-yellow-400 border-t-transparent rounded-full animate-spin"></div>
                                </div>
                            ) : !hasAny ? (
                                <div className="text-center py-24">
                                    <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5"
                                            d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                    </svg>
                                    <p className="text-gray-500 text-lg">
                                        {currentLanguage === 'en' ? 'No articles found.' : 'Chưa có bài viết nào.'}
                                    </p>
                                </div>
                            ) : (
                                <section className="mb-4">
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-4">
                                        {regularPosts.map((post) => (
                                            <ArticleCard key={post.id || post.slug} post={post} currentLanguage={currentLanguage} />
                                        ))}
                                    </div>
                                    <Pagination
                                        currentPage={currentPage}
                                        totalPages={totalPages}
                                        onPageChange={onPageChange}
                                    />
                                </section>
                            )}
                        </div>

                        {/* Right column – services slider */}
                        <div className="w-full lg:w-80 xl:w-96 flex-shrink-0 lg:sticky lg:top-24 self-start">
                            <ServicesMiniSlider currentLanguage={currentLanguage} />
                        </div>
                    </div>

                </div>
            </main>
        </div>
    );
};

export default RaarticlePageTemplate;
