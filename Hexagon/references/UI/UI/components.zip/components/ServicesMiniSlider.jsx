// File này đã được chuyển sang ../../islands/ServicesMiniSlider.jsx
// Import từ islands để đảm bảo client-side hydration đúng cách
import ServicesMiniSlider from '../../islands/ServicesMiniSlider';
export default ServicesMiniSlider;
