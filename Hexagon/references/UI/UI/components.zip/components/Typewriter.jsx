import React, { useState, useEffect, useRef } from 'react'

/**
 * Component hiệu ứng chữ chạy (typewriter) 2 chiều.
 * - mode='type'  : gõ từng ký tự cho đến khi đủ text
 * - mode='erase' : xóa từng ký tự cho đến khi rỗng
 *
 * @param {string}         text        - Chuỗi cần xử lý
 * @param {number}         speed       - Tốc độ gõ (ms / ký tự)
 * @param {number}         eraseSpeed  - Tốc độ xóa (ms / ký tự)
 * @param {boolean}        start       - Có được phép chạy hay chưa
 * @param {boolean}        showCursor  - Có hiển thị con trỏ nhấp nháy hay không
 * @param {'type'|'erase'} mode        - Chế độ gõ hay xóa
 * @param {Function}       onDone      - Callback khi hoàn tất (gõ hết hoặc xóa hết)
 */
function Typewriter({
    text = '',
    speed = 80,
    eraseSpeed = 45,
    start = true,
    showCursor = true,
    mode = 'type',
    onDone,
    ...rest
}) {
    const [display, setDisplay] = useState('')
    // Dùng ref để tránh stale closure và tránh loop effect khi onDone thay đổi
    const onDoneRef = useRef(onDone)
    onDoneRef.current = onDone
    // Đánh dấu đã gọi onDone để chỉ gọi 1 lần / mỗi lần chạy
    const calledDoneRef = useRef(false)

    // Reset display khi text hoặc mode đổi (đổi ngôn ngữ, chuyển pha gõ↔xóa)
    useEffect(() => {
        setDisplay(mode === 'erase' ? text : '')
        calledDoneRef.current = false
    }, [text, mode])

    // Gõ hoặc xóa từng ký tự khi đã được phép start
    useEffect(() => {
        if (!start) return
        const finished = mode === 'type'
            ? display.length >= text.length
            : display.length === 0
        if (finished) {
            if (!calledDoneRef.current) {
                calledDoneRef.current = true
                onDoneRef.current?.()
            }
            return
        }
        const nextLen = mode === 'type' ? display.length + 1 : display.length - 1
        const delay = mode === 'type' ? speed : eraseSpeed
        const timer = setTimeout(() => {
            setDisplay(text.slice(0, nextLen))
        }, delay)
        return () => clearTimeout(timer)
    }, [display, start, text, speed, eraseSpeed, mode])

    return (
        <span {...rest}>
            {display}
            {/* Con trỏ nhấp nháy - chỉ hiện khi đang hoạt động */}
            {start && showCursor && (
                <span
                    aria-hidden="true"
                    className="inline-block w-[3px] h-[0.85em] ml-1 bg-current align-middle animate-pulse"
                />
            )}
        </span>
    )
}

export default Typewriter
