import { useEffect, useRef } from 'react'
import { geoOrthographic, geoPath, geoBounds, geoGraticule } from 'd3-geo'
import { timer } from 'd3-timer'

// Quả địa cầu chấm (dotted globe) — dùng d3-geo + Canvas 2D.
// Auto-xoay + kéo để xoay. Đã BỎ scroll-zoom để không chặn scroll trang.
// Chuyển từ TS sang JS thuần khi tích hợp vào project (không phải shadcn).
//
// Lưu ý: vẽ ~hàng nghìn chấm đất liền mỗi frame → khá tốn CPU; nếu giật có thể
// giảm dotSpacing hoặc tắt auto-xoay. Cần mạng để fetch GeoJSON đất liền.
export default function HeroBackground3D({ width = 600, height = 600, className = '' }) {
    const canvasRef = useRef(null)

    useEffect(() => {
        if (!canvasRef.current) return
        const canvas = canvasRef.current
        const context = canvas.getContext('2d')
        if (!context) return

        // Kích thước responsive (giới hạn theo cửa sổ)
        const containerWidth = Math.min(width, window.innerWidth - 40)
        const containerHeight = Math.min(height, window.innerHeight - 100)
        const radius = Math.min(containerWidth, containerHeight) / 2.5

        const dpr = window.devicePixelRatio || 1
        canvas.width = containerWidth * dpr
        canvas.height = containerHeight * dpr
        canvas.style.width = `${containerWidth}px`
        canvas.style.height = `${containerHeight}px`
        context.scale(dpr, dpr)

        const projection = geoOrthographic()
            .scale(radius)
            .translate([containerWidth / 2, containerHeight / 2])
            .clipAngle(90)

        const path = geoPath().projection(projection).context(context)

        // --- point-in-polygon: xác định 1 chấm có nằm trong đa giác đất liền ---
        const pointInPolygon = (point, polygon) => {
            const [x, y] = point
            let inside = false
            for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
                const [xi, yi] = polygon[i]
                const [xj, yj] = polygon[j]
                if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) {
                    inside = !inside
                }
            }
            return inside
        }

        const pointInFeature = (point, feature) => {
            const geometry = feature.geometry
            if (geometry.type === 'Polygon') {
                const coords = geometry.coordinates
                if (!pointInPolygon(point, coords[0])) return false
                for (let i = 1; i < coords.length; i++) {
                    if (pointInPolygon(point, coords[i])) return false
                }
                return true
            } else if (geometry.type === 'MultiPolygon') {
                for (const polygon of geometry.coordinates) {
                    if (pointInPolygon(point, polygon[0])) {
                        let inHole = false
                        for (let i = 1; i < polygon.length; i++) {
                            if (pointInPolygon(point, polygon[i])) { inHole = true; break }
                        }
                        if (!inHole) return true
                    }
                }
                return false
            }
            return false
        }

        // Rải chấm bên trong mỗi feature đất liền
        const generateDotsInPolygon = (feature, dotSpacing = 16) => {
            const dots = []
            const [[minLng, minLat], [maxLng, maxLat]] = geoBounds(feature)
            const stepSize = dotSpacing * 0.08
            for (let lng = minLng; lng <= maxLng; lng += stepSize) {
                for (let lat = minLat; lat <= maxLat; lat += stepSize) {
                    if (pointInFeature([lng, lat], feature)) dots.push([lng, lat])
                }
            }
            return dots
        }

        const allDots = []
        let landFeatures = null

        const render = () => {
            context.clearRect(0, 0, containerWidth, containerHeight)
            const currentScale = projection.scale()
            const scaleFactor = currentScale / radius

            // Ocean (nền đen của cầu)
            context.beginPath()
            context.arc(containerWidth / 2, containerHeight / 2, currentScale, 0, 2 * Math.PI)
            context.fillStyle = '#1D6A49'
            context.fill()
            context.strokeStyle = '#ffffff'
            context.lineWidth = 2 * scaleFactor
            context.stroke()

            if (landFeatures) {
                // Lưới kinh/vĩ tuyến (graticule)
                context.beginPath()
                path(geoGraticule()())
                context.strokeStyle = '#ffffff'
                context.lineWidth = 1 * scaleFactor
                context.globalAlpha = 0.25
                context.stroke()
                context.globalAlpha = 1

                // Đường bao đất liền
                context.beginPath()
                landFeatures.features.forEach((feature) => path(feature))
                context.strokeStyle = '#ffffff'
                context.lineWidth = 1 * scaleFactor
                context.stroke()

                // Chấm halftone trên đất liền
                allDots.forEach((dot) => {
                    const projected = projection([dot.lng, dot.lat])
                    if (
                        projected &&
                        projected[0] >= 0 && projected[0] <= containerWidth &&
                        projected[1] >= 0 && projected[1] <= containerHeight
                    ) {
                        context.beginPath()
                        context.arc(projected[0], projected[1], 1.2 * scaleFactor, 0, 2 * Math.PI)
                        context.fillStyle = '#999999'
                        context.fill()
                    }
                })
            }
        }

        const loadWorldData = async () => {
            try {
                const response = await fetch(
                    'https://raw.githubusercontent.com/martynafford/natural-earth-geojson/refs/heads/master/110m/physical/ne_110m_land.json',
                )
                if (!response.ok) throw new Error('load failed')
                landFeatures = await response.json()
                landFeatures.features.forEach((feature) => {
                    generateDotsInPolygon(feature, 16).forEach(([lng, lat]) => allDots.push({ lng, lat }))
                })
                render()
            } catch {
                // Lỗi fetch → vẫn vẽ được cầu (chỉ outline), không hiện lỗi trên hero
            }
        }

        // Auto-xoay
        const rotation = [0, 0]
        let autoRotate = true
        const rotationSpeed = 0.5
        const rotationTimer = timer(() => {
            if (autoRotate) {
                rotation[0] += rotationSpeed
                projection.rotate(rotation)
                render()
            }
        })

        // Kéo để xoay (manual)
        const handleMouseDown = (event) => {
            autoRotate = false
            const startX = event.clientX
            const startY = event.clientY
            const startRotation = [...rotation]

            const handleMouseMove = (moveEvent) => {
                const dx = moveEvent.clientX - startX
                const dy = moveEvent.clientY - startY
                rotation[0] = startRotation[0] + dx * 0.5
                rotation[1] = Math.max(-90, Math.min(90, startRotation[1] - dy * 0.5))
                projection.rotate(rotation)
                render()
            }
            const handleMouseUp = () => {
                document.removeEventListener('mousemove', handleMouseMove)
                document.removeEventListener('mouseup', handleMouseUp)
                setTimeout(() => { autoRotate = true }, 10)
            }
            document.addEventListener('mousemove', handleMouseMove)
            document.addEventListener('mouseup', handleMouseUp)
        }

        canvas.addEventListener('mousedown', handleMouseDown)
        loadWorldData()

        // Cleanup
        return () => {
            rotationTimer.stop()
            canvas.removeEventListener('mousedown', handleMouseDown)
        }
    }, [width, height])

    return (
        <div className={`relative ${className}`}>
            <canvas
                ref={canvasRef}
                className="w-full h-auto"
                style={{ maxWidth: '100%', height: 'auto' }}
            />
        </div>
    )
}
