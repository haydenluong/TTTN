import React from 'react';

// Prop heightClass cho phép override chiều cao card từ nơi gọi (mặc định 260px để giữ nguyên v1)
// Prop hoverImage: ảnh sẽ crossfade lên khi hover (thay vì zoom ảnh gốc)
const ServiceCard = ({ href, title, description, image, hoverImage, heightClass = 'h-[260px]' }) => {
  return (
    <a
      href={href}
      className={`group relative block w-full ${heightClass} rounded-xl overflow-hidden cursor-pointer shadow-lg transition-transform duration-300 hover:-translate-y-2`}
    >
      {/* Ảnh gốc (luôn hiển thị, không zoom để tránh xung đột với crossfade) */}
      {image ? (
        <img
          src={image}
          alt={title}
          className="absolute inset-0 w-full h-full object-cover"
        />
      ) : (
        <div className="absolute inset-0 bg-gradient-to-br from-gray-700 to-gray-900" />
      )}

      {/* Ảnh hover - được tải sẵn trong DOM (opacity-0) nên không giật khi hover lần đầu.
          Chỉ transition opacity (GPU-friendly) + will-change để mượt. */}
      {hoverImage && (
        <img
          src={hoverImage}
          alt=""
          aria-hidden="true"
          loading="eager"
          className="absolute inset-0 w-full h-full object-cover opacity-0 transition-opacity duration-500 ease-out [will-change:opacity] group-hover:opacity-100"
        />
      )}

      {/* Content Container */}
      <div className="absolute inset-0 p-6 flex flex-col justify-start">
        <div className="transform translate-y-0">
          <h3 className="text-xl font-bold text-yellow-500 mb-0 group-hover:mb-3 transition-all duration-300">{title}</h3>

          <div className="max-h-0 opacity-0 group-hover:max-h-40 group-hover:opacity-100 transition-all duration-500 ease-in-out overflow-hidden">
            <p className="text-gray text-sm mb-4 line-clamp-3">{description}</p>
            <span className="inline-block text-blue-600 font-bold text-sm">
              Xem chi tiết &rarr;
            </span>
          </div>
        </div>
      </div>
    </a>
  );
};

export default ServiceCard;
