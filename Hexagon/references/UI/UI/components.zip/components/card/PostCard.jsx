import { getPostImageUrl } from '../../../services/postService';

const PostCard = ({ href,  title, description, date, image, category, subcategory, categoryTitle, subcategoryTitle, categories = [] }) => {
  return (
    <article className="group h-full">
      <a href={href} className="flex flex-col h-full bg-white border border-gray-200 rounded-xl overflow-hidden transition-all duration-200 hover:shadow-lg hover:-translate-y-1">
        <div className="relative overflow-hidden h-48">
          {image ? (
            (() => {
              const imgSrc = getPostImageUrl(image) || image;
              return (
                <img src={imgSrc} alt={title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"/>
              );
            })()
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
              <svg className="w-16 h-16 text-gray-600" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
              </svg>
            </div>
          )}

          {date && (
            <div className="absolute top-3 left-3">
              <span className="bg-gray-800 text-white text-xs px-3 py-1.5 rounded-full border border-gray-700 font-medium">{date}</span>
            </div>
          )}
        </div>

        <div className="flex flex-col flex-1 p-6">
          {( (Array.isArray(categories) && categories.length) || category || subcategory || categoryTitle || subcategoryTitle) && (
            <div className="mb-3">
              <div className="flex items-center gap-2 text-sm flex-wrap">
                {(() => {
                    const names = [];

                    if (Array.isArray(categories) && categories.length) {
                      categories.forEach((c) => {
                        if (!c) return;
                        if (typeof c === 'string') {
                          names.push(c);
                          return;
                        }
                        const parentName = c.parent && (c.parent.name || c.parent.title);
                        const ownName = c.name || c.title;
                        if (parentName) names.push(parentName);
                        else if (ownName) names.push(ownName);
                      });
                    } else if (category) {
                      names.push(category);
                    } else if (categoryTitle) {
                      names.push(...categoryTitle.split(',').map(s => s.trim()).filter(Boolean));
                    }

                    // dedupe preserving order
                    const seen = new Set();
                    const badgeList = names.filter(n => n && !seen.has(n) && seen.add(n));

                    return badgeList.map((name, idx) => (
                      <span
                        key={name + '-' + idx}
                        className={
                          idx === 0
                            ? 'bg-blue-50 text-blue-700 px-3 py-1 rounded-full font-medium text-xs border border-blue-100'
                            : 'bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-xs border border-gray-200'
                        }
                        title={name}
                      >
                        {name}
                      </span>
                    ));
                })()}
              </div>
            </div>
          )}

            <h3 className="text-lg font-bold text-gray-900 mb-3 line-clamp-2 transition-colors duration-300 min-h-[3.5rem] flex items-start">
            {title}
          </h3>
          
          <div className="flex-1 flex flex-col justify-between">
            <p className="text-gray-700 text-sm leading-relaxed mb-4 line-clamp-3 flex-1">
              {description}
            </p>

            <div className="flex items-center justify-between mt-auto">
              <span className="inline-flex items-center text-blue-600 font-medium text-sm group-hover:text-blue-800 transition-colors">
                Xem chi tiết &rarr;
              </span>
            </div>
          </div>
        </div>
      </a>
    </article>
  );
};

export default PostCard;