import React from 'react';
import { useTranslation } from 'react-i18next';

const Modal = ({ isOpen, onClose, title, slogan, description, link, linkText }) => {
  const { t } = useTranslation();
  const defaultLinkText = linkText || t('ecosystem.modal.visitWebsite');
  if (!isOpen) return null;

  const handleModalClick = (e) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div
      className="modal fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4"
      onClick={handleModalClick}
    >
      <div className="bg-white/10 backdrop-blur-lg border border-white/10 text-white rounded-lg shadow-2xl max-w-lg w-full transform transition-all duration-300">
        <div className="p-6 md:p-8">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold text-gold-accent">{title}</h2>
              <p className="text-gray-400 mt-1">{slogan}</p>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white text-3xl leading-none"
            >
              ×
            </button>
          </div>
          <div className="mt-6">
            <p className="text-gray-300">{description}</p>
          </div>
          <div className="mt-8 text-right">
            <a
              href={link}
              target="_blank"
              rel="noopener noreferrer"
              className="text-white py-2 px-6 rounded-lg transition-colors bg-orange-600 hover:bg-yellow-400"
            >
              {defaultLinkText}
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Modal;
