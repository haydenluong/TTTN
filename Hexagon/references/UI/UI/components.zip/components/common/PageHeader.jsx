import React from 'react';
import { useTranslation } from 'react-i18next';

const PageHeader = ({ title, heading, description }) => {
    const { t } = useTranslation();

    return (
        <section className="text-left mb-10 text-base">
            <nav className="text-sm mb-2 text-gray-400">
                <a href="/" className="hover:text-gold-accent">{t('nav.home', 'Trang chủ')} </a> &gt;
                <a href="/#dich-vu" className="hover:text-gold-accent"> {t('nav.services', 'Dịch vụ')} </a> &gt;
                <span className="text-gray-700"> {title}</span>
            </nav>
            {/* <h1 className="text-4xl lg:text-5xl font-bold text-gold-accent mb-4">{heading || title}</h1>
            <p className="max-w-3xl mx-auto text-lg text-gray-300">
                {description}
            </p> */}
        </section>
    );
};

export default PageHeader;
