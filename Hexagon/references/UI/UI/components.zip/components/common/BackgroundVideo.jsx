import React, { useRef, useEffect } from 'react';

const BackgroundVideo = ({ videoSrc = '/assets/videos/hhc-background.mp4' }) => {
  const videoRef = useRef(null);

  useEffect(() => {
    const v = videoRef.current;
    if (v) {
      v.muted = true;
      v.playsInline = true;
      const playPromise = v.play();
      if (playPromise && typeof playPromise.then === 'function') {
        playPromise.catch((e) => {
        });
      }
    }
  }, [videoSrc]);

  return (
    <video ref={videoRef} autoPlay loop muted playsInline className="video-bg" style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', objectFit: 'cover', zIndex: -1, opacity: 0.12 }}>
      <source src={videoSrc} type="video/mp4" />
      Your browser does not support the video tag.
    </video>
  );
};

export default BackgroundVideo;