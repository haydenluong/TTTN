
import React, { useState, useEffect } from 'react';

/**
 * ScrollToTop Component
 * Hiển thị nút cuộn lên đầu trang khi người dùng cuộn xuống
 * @param {number} showAfter - Số pixel cuộn xuống để hiển thị nút (mặc định: 300)
 * @param {string} position - Vị trí hiển thị ('bottom-right', 'bottom-left')
 * @param {string} size - Kích thước nút ('small', 'medium', 'large')
 */
/**
 * @param {{ showAfter?: number, position?: 'bottom-right' | 'bottom-left', size?: 'small' | 'medium' | 'large' }} props
 */
const ScrollToTopButton = ({
  showAfter = 300,
  position = 'bottom-right',
  size = 'medium',
}) => {
  const [isVisible, setIsVisible] = useState(false);

  // Theo dõi vị trí cuộn
  useEffect(() => {
    const toggleVisibility = () => {
      if (window.pageYOffset > showAfter) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', toggleVisibility);

    return () => {
      window.removeEventListener('scroll', toggleVisibility);
    };
  }, [showAfter]);

  // Cuộn lên đầu trang
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  // Xác định vị trí
  const positionClasses = {
    'bottom-right': 'bottom-6 right-6 md:bottom-8 md:right-8 lg:bottom-12 lg:right-12',
    'bottom-left': 'bottom-6 left-6 md:bottom-8 md:left-8 lg:bottom-12 lg:left-12'
  };

  // Xác định kích thước
  const sizeClasses = {
    'small': 'w-8 h-8 md:w-10 md:h-10',
    'medium': 'w-10 h-10 md:w-11 md:h-11 lg:w-12 lg:h-12',
    'large': 'w-12 h-12 md:w-14 md:h-14 lg:w-16 lg:h-16'
  };

  // Xác định kích thước icon
  const iconSizeClasses = {
    'small': 'w-4 h-4 md:w-5 md:h-5',
    'medium': 'w-5 h-5 md:w-5 md:h-5 lg:w-6 lg:h-6',
    'large': 'w-6 h-6 md:w-7 md:h-7 lg:w-8 lg:h-8'
  };

  return (
    <>
      {isVisible && (
        <button
          onClick={scrollToTop}
          className={`fixed ${positionClasses[position]} ${sizeClasses[size]} 
                        bg-gradient-to-br from-orange-400 to-orange-500 
                        hover:from-orange-500 hover:to-orange-600
                        text-white rounded-full shadow-lg 
                        transition-all duration-300 
                        hover:scale-110 hover:shadow-2xl
                        focus:outline-none focus:ring-4 focus:ring-orange-300
                        z-[9998]
                        flex items-center justify-center
                        animate-fadeIn`}
          aria-label="Cuộn lên đầu trang"
          title="Cuộn lên đầu trang"
        >
          {/* Icon mũi tên lên */}
          <svg
            className={`${iconSizeClasses[size]} transition-transform duration-300 group-hover:-translate-y-1`}
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M5 10l7-7m0 0l7 7m-7-7v18"
            />
          </svg>

          {/* Hiệu ứng pulse khi hover */}
          <span className="absolute inset-0 rounded-full bg-orange-400 opacity-0 hover:opacity-20 animate-pulse"></span>
        </button>
      )}

      <style>{`
                @keyframes fadeIn {
                    from {
                        opacity: 0;
                        transform: translateY(20px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }

                .animate-fadeIn {
                    animation: fadeIn 0.3s ease-out;
                }
            `}</style>
    </>
  );
};

export default ScrollToTopButton;
