import React, { useState, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import Typewriter from './Typewriter'

/**
 * Luân phiên 4 tiêu đề dịch vụ bằng hiệu ứng typewriter (1 dòng duy nhất).
 * Vòng lặp: gõ title[i] → giữ 1.5s → xóa → gõ title[i+1] → ... → title cuối → quay lại title đầu.
 *
 * Dữ liệu lấy từ i18n key `hero.services` (mảng các object, mỗi object chứa 1 title).
 */
function ServicesTypewriter() {
    const { t } = useTranslation();

    // Lấy mảng services từ i18n (returnObjects để nhận giá trị không phải string)
    const raw = t('hero.services', { returnObjects: true });
    // Trích giá trị title từ cấu trúc [{title1: ...}, {title2: ...}, ...]
    const items = (Array.isArray(raw) ? raw : [])
        .map(o => (o && typeof o === 'object' ? Object.values(o)[0] : ''))
        .filter(Boolean);

    // Chỉ số title đang hiển thị (0..items.length-1)
    const [idx, setIdx] = useState(0);
    // Trạng thái vòng lặp: 'type' → 'pause' → 'erase' → (sang idx tiếp theo) → 'type' → ...
    const [mode, setMode] = useState('type');

    // Pha "pause": đợi 1.5s sau khi gõ xong rồi mới bắt đầu xóa
    useEffect(() => {
        if (mode !== 'pause') return;
        const timer = setTimeout(() => setMode('erase'), 1500);
        return () => clearTimeout(timer);
    }, [mode]);

    // Nếu không có dữ liệu thì không render gì
    if (items.length === 0) return null;

    const current = items[idx % items.length];

    return (
        <Typewriter
            text={current}
            mode={mode === 'erase' ? 'erase' : 'type'}
            start={mode === 'type' || mode === 'erase'}
            showCursor={mode === 'type' || mode === 'erase'}
            onDone={() => {
                if (mode === 'type') {
                    setMode('pause');
                } else if (mode === 'erase') {
                    // Chuyển sang title tiếp theo (vòng vô hạn theo items.length)
                    setIdx(i => i + 1);
                    setMode('type');
                }
            }}
        />
    );
}

export default ServicesTypewriter
