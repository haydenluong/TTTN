import React from 'react';
import PageHeader from './common/PageHeader';

const FALLBACK = {
  vi: {
    ctaBtnText: 'Liên hệ Tư vấn',
    solutionsTitle: 'Giải pháp nổi bật',
    processTitle: 'Quy trình thực hiện',
    processDescription: 'Một quy trình khoa học từ khâu ý tưởng đến vận hành, đảm bảo dự án mang lại giá trị thực tiễn và phù hợp với mục tiêu kinh doanh.',
    ctaTitle: 'Bạn đã sẵn sàng?',
    ctaDescription: 'Liên hệ với chúng tôi để được tư vấn giải pháp phù hợp nhất cho doanh nghiệp của bạn.',
    readyCta1: 'Về trang chủ',
    readyCta2: 'Liên hệ Tư vấn',
  },
  en: {
    ctaBtnText: 'Contact Us',
    solutionsTitle: 'Key Solutions',
    processTitle: 'Our Process',
    processDescription: 'A structured process from ideation to delivery, ensuring every project delivers real value aligned with your business goals.',
    ctaTitle: 'Ready to get started?',
    ctaDescription: 'Contact us to receive the most suitable solution consulting for your business.',
    readyCta1: 'Back to home',
    readyCta2: 'Contact Us',
  },
};

const ServicePageTemplate = ({
  lang = 'vi',
  title,
  heading,
  description,
  imageSrc,
  imageAlt,
  features = [],
  processSteps = [],
  ctaTitle,
  ctaDescription,
  solutionsTitle,
  processTitle,
  processDescription,
  ctaBtnText,
  readyCta1,
  readyCta2,
  children
}) => {
  const fb = FALLBACK[lang] || FALLBACK.vi;
  return (
    <div className="antialiased text-base bg-[#F8FAFC] min-h-screen">
      <main className="pt-28 md:pt-32">
        <div className="container mx-auto px-6 py-6">

          <PageHeader title={title} heading={heading} description={description} />

          {/* Hero Section */}
          <section className="grid md:grid-cols-2 gap-12 items-center mb-20 lg:mb-32">
            <div className="text-left">
              <h1 className="text-4xl lg:text-5xl font-bold text-yellow-500 mb-6 leading-tight">
                {heading || title}
              </h1>
              <p className="max-w-xl text-lg text-gray-700 mb-10 leading-relaxed">
                {description}
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <a href="/#lien-he" className="px-8 py-3.5 bg-[#f59e0b] hover:bg-[#d97706] text-white font-bold rounded-lg transition-all shadow-lg shadow-yellow-500/20 text-center">
                  {ctaBtnText || fb.ctaBtnText}
                </a>
              </div>
            </div>
            {imageSrc && (
              <div className="relative max-w-[600px] mx-auto w-full">
                <div className="rounded-lg overflow-hidden shadow-2xl transition-transform hover:scale-[1.01] duration-500 aspect-[16/9]">
                  <img
                    src={imageSrc}
                    alt={imageAlt || title}
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            )}
          </section>

          {/* Features/Solutions Section */}
          {features.length > 0 && (
            <section className="mb-20 lg:mb-32">
              <div className="text-center mb-16">
                <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">{solutionsTitle || fb.solutionsTitle}</h2>
                <div className="w-16 h-1 bg-gold-accent mx-auto rounded-full"></div>
              </div>

              <div className="grid md:grid-cols-3 gap-8">
                {(features.length > 3 ? features.slice(0, 3) : features).map((feature, index) => (
                  <div key={index} className="bg-white border border-gray-200 shadow-sm rounded-xl p-8 transition-all hover:shadow-md hover:border-gold-accent/40 group">
                    <div className="w-10 h-10 bg-green-500/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-green-500/20 transition-colors">
                      <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <h4 className="text-xl font-bold text-gray-900 mb-4">{feature.title}</h4>
                    <p className="text-gray-700 text-base leading-relaxed">{feature.description}</p>
                  </div>
                ))}
              </div>

              {/* Show remaining features as list */}
              {features.length > 3 && (
                <div className="mt-12 grid md:grid-cols-2 gap-6">
                  {features.slice(3).map((feature, index) => (
                    <div key={index} className="flex items-start bg-white p-4 rounded-xl border border-gray-200 shadow-sm hover:border-gold-accent/30 transition-colors group">
                      <svg className="w-6 h-6 text-gold-accent mr-3 mt-1 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <div>
                        <h4 className="font-bold text-lg text-gray-900 mb-1">{feature.title}</h4>
                        <p className="text-gray-700 text-base leading-relaxed">{feature.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>
          )}

          {/* Custom Content (Children) */}
          {children}

          {/* Process Steps Section */}
          {processSteps.length > 0 && (
            <section className="mb-20 lg:mb-32">
              <div className="text-center mb-16">
                <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">{processTitle || fb.processTitle}</h2>
                <p className="text-gray-600 mt-2 max-w-2xl mx-auto">
                  {processDescription || fb.processDescription}
                </p>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 text-center">
                {processSteps.map((step, index) => (
                  <div key={index} className="bg-white p-8 rounded-xl border border-gray-200 shadow-sm transition-all hover:shadow-md">
                    <div className="text-3xl font-bold text-gold-accent mb-4">
                      {String(index + 1).padStart(2, '0')}
                    </div>
                    <h4 className="font-bold text-gray-900 mb-2">{step.title}</h4>
                    <p className="text-base text-gray-700 leading-relaxed">{step.description}</p>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* CTA Section */}
          <section className="bg-[#0D5939] bg-gradient-to-r from-gray-800/30 rounded-2xl p-8 md:p-16 text-center border border-white/10 backdrop-blur-sm">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">{ctaTitle || fb.ctaTitle}</h2>
            <p className="text-white/80 mb-10 max-w-2xl mx-auto text-lg leading-relaxed">{ctaDescription || fb.ctaDescription}</p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <a href="/" className="px-10 py-3.5 bg-white/5 hover:bg-white/10 border border-white/10 text-white font-bold rounded-lg transition-all text-center">
                {readyCta1 || fb.readyCta1}
              </a>
              <a href="/#lien-he" className="px-10 py-3.5 bg-[#f59e0b] hover:bg-[#d97706] text-white font-bold rounded-lg transition-all shadow-lg shadow-yellow-500/20 text-center">
                {readyCta2 || fb.readyCta2}
              </a>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
};

export default ServicePageTemplate;
