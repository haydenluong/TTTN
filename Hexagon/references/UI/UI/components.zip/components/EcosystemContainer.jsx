import React, { useState, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import '../../locales/i18n.js';
import Modal from './Modal';

const EcosystemContainer = () => {
  const { t } = useTranslation();
  const [selectedSubsidiary, setSelectedSubsidiary] = useState(null);

  const subsidiaries = [
    {
      id: 'myu',
      name: t('ecosystem.subsidiaries.myu.name'),
      slogan: t('ecosystem.subsidiaries.myu.slogan'),
      description: t('ecosystem.subsidiaries.myu.description'),
      logo: '/assets/images/logo-myU.png',
      tooltip: t('ecosystem.subsidiaries.myu.tooltip'),
      url: 'https://myu.vn'
    },
    {
      id: 'hunix',
      name: t('ecosystem.subsidiaries.hunix.name'),
      slogan: t('ecosystem.subsidiaries.hunix.slogan'),
      description: t('ecosystem.subsidiaries.hunix.description'),
      logo: '/assets/images/logo-hhc.png',
      tooltip: t('ecosystem.subsidiaries.hunix.tooltip'),
      url: 'https://ttth.vhu.edu.vn'
    },
    {
      id: 'miga',
      name: t('ecosystem.subsidiaries.miga.name'),
      slogan: t('ecosystem.subsidiaries.miga.slogan'),
      description: t('ecosystem.subsidiaries.miga.description'),
      logo: '/assets/images/logo-miga.png',
      tooltip: t('ecosystem.subsidiaries.miga.tooltip'),
      url: 'https://pay.migame.vn'
    },
    {
      id: 'vantuo_ng',
      name: t('ecosystem.subsidiaries.vantuo_ng.name'),
      slogan: t('ecosystem.subsidiaries.vantuo_ng.slogan'),
      description: t('ecosystem.subsidiaries.vantuo_ng.description'),
      logo: '/assets/images/logo-vt.png',
      tooltip: t('ecosystem.subsidiaries.vantuo_ng.tooltip'),
      url: 'https://vt.edu.vn'
    },
    {
      id: 'zeno',
      name: t('ecosystem.subsidiaries.zeno.name'),
      slogan: t('ecosystem.subsidiaries.zeno.slogan'),
      description: t('ecosystem.subsidiaries.zeno.description'),
      logo: '/assets/images/logo-hhc.png',
      tooltip: t('ecosystem.subsidiaries.zeno.tooltip'),
      url: '#'
    },
    {
      id: 'cntt',
      name: t('ecosystem.subsidiaries.cntt.name'),
      slogan: t('ecosystem.subsidiaries.cntt.slogan'),
      description: t('ecosystem.subsidiaries.cntt.description'),
      logo: '/assets/images/logo-vhu.png',
      tooltip: t('ecosystem.subsidiaries.cntt.tooltip'),
      url: 'https://cntt.vhu.edu.vn'
    }
  ];

  const SubsidiaryElement = ({ subsidiary, position, size }) => {
    // More responsive sizing based on container width with larger minimums
    // Scale based on viewport width
    const containerWidth = size?.width || 640;

    // Increased scaling for even larger hexagons
    const scaleFactor = containerWidth < 480 ? 0.19 :
      containerWidth < 576 ? 0.20 :
        containerWidth < 768 ? 0.21 : 0.22;

    // Much larger minimum sizes for all screens
    const minWidth = containerWidth < 576 ? 90 : 100;
    const minHeight = containerWidth < 576 ? 75 : 88;

    const itemW = Math.max(minWidth, Math.round(containerWidth * scaleFactor));
    const itemH = Math.max(minHeight, Math.round(containerWidth * (scaleFactor * 0.87)));

    return (
      <div
        className="subsidiary"
        style={{
          position: 'absolute',
          left: `${position.x}px`,
          top: `${position.y}px`,
          width: `${itemW}px`,
          height: `${itemH}px`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          textAlign: 'center',
          cursor: 'pointer',
          transition: 'all 0.25s ease-in-out'
        }}
        onClick={() => setSelectedSubsidiary(subsidiary)}
      >
        <div className="subsidiary-inner" style={{ width: '100%', height: '100%', position: 'relative', right: '12%', bottom: '5%' }}>
          <svg className="hexagon-svg" viewBox="0 0 100 86.6" preserveAspectRatio="xMidYMid meet" style={{ position: 'absolute', top: 0, width: '100%', height: '100%' }}>
            <path
              className="hexagon-path"
              d="M97.7,46.3 A8,8 0 0 0 97.7,40.3 L77.3,4 A8,8 0 0 0 70.4,0 L29.6,0 A8,8 0 0 0 22.7,4 L2.3,40.3 A8,8 0 0 0 2.3,46.3 L22.7,82.6 A8,8 0 0 0 29.6,86.6 L70.4,86.6 A8,8 0 0 0 77.3,82.6 L97.7,46.3 Z"
              fill="rgba(255, 255, 255, 0.2)"
              stroke="rgba(255, 255, 255, 0.3)"
              strokeWidth="1"
            />
          </svg>
          <div className="company-name-tooltip">
            {subsidiary.name}
          </div>
          <div style={{ position: 'absolute', zIndex: 1, width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <img src={subsidiary.logo} alt={`${subsidiary.name} Logo`} style={{ width: Math.round(itemW * 0.65) + 'px', height: Math.round(itemH * 0.65) + 'px', objectFit: 'contain' }} />
          </div>
        </div>
      </div>
    );
  };

  // Responsive measurement and positions
  const containerRef = useRef(null);
  const [size, setSize] = useState({ width: 800, height: 800 });

  useEffect(() => {
    const updateSize = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        // Get actual width of container and make it square with same height
        const w = rect.width;
        // Use same value for height to maintain aspect ratio
        setSize({ width: w, height: w });
      }
    };

    // Initial update
    updateSize();

    // Create a resize observer to handle container size changes
    const resizeObserver = new ResizeObserver(updateSize);
    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    // Also listen to window resize events
    window.addEventListener('resize', updateSize);

    // Cleanup
    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', updateSize);
    };
  }, []);

  const calculatePositions = () => {
    const numItems = subsidiaries.length;
    const centerX = size.width / 2;
    const centerY = size.height / 2;

    // Adjust radius to be closer to center
    // Smaller radius values to keep hexagons closer to center
    const minRadius = size.width < 576 ? 110 : 140;
    const radius = Math.max(minRadius, Math.round(Math.min(size.width, size.height) * 0.33));

    return subsidiaries.map((sub, i) => {
      const angle = (i / numItems) * 2 * Math.PI - (Math.PI / 2);

      // Adjusted size calculations for better responsive behavior
      const itemW = Math.max(48, Math.round(size.width * 0.16));
      const itemH = Math.max(42, Math.round(size.height * 0.14));

      const x = Math.round(centerX + radius * Math.cos(angle) - itemW / 2);
      const y = Math.round(centerY + radius * Math.sin(angle) - itemH / 2);
      return { ...sub, position: { x, y } };
    });
  };

  const subsidiariesWithPositions = calculatePositions();

  return (
    <>
      <div
        ref={containerRef}
        className="ecosystem-container"
        style={{
          position: 'relative',
          width: '100%',
          height: `${size.height}px`, // Fall back if aspectRatio not supported
          margin: '0 auto'
        }}
      >
        <a href="#gioi-thieu" className="center-logo" style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', zIndex: 20 }}>
          <div className="hexagon-logo-shape flex items-center justify-center">
            <img
              src="/assets/images/logo-hhc.png"
              alt="Hexagon Logo"
              style={{
                width: '75%',  // Make the logo properly sized within the hexagon
                height: 'auto',
                objectFit: 'contain',
                position: 'relative',
                zIndex: 1,
                filter: 'drop-shadow(0 0 4px rgba(66, 213, 120, 0.3))'
              }}
            />
          </div>
        </a>

        {subsidiariesWithPositions.map((subsidiary) => (
          <SubsidiaryElement key={subsidiary.id} subsidiary={subsidiary} position={subsidiary.position} size={size} />
        ))}
      </div>

      <Modal isOpen={!!selectedSubsidiary} onClose={() => setSelectedSubsidiary(null)} title={selectedSubsidiary?.name} slogan={selectedSubsidiary?.slogan} description={selectedSubsidiary?.description} link={selectedSubsidiary?.url} />
    </>
  );
};

export default EcosystemContainer;
